# Changelog

## 1.0.0 — 2026-09-17
- First complete runnable research/art release.
- Dark specimen-field dashboard with FRONTIER / OPEN / 5s / 10s / 20s / REPLAY / FOR YOU / FAVORITES.
- Immutable-core lineage hashing enforced across descendants.
- Real Lenia Orbium source trajectory generated from reference equations and seed.
- Chladni/circular-membrane eigenmode renderer using adapted MIT-licensed upstream mathematics.
- Equation-level Manicka–Levin bioelectric field trajectories with multiple fixed source variants.
- NS26 retained as explicitly DERIVED pending a full executable-paper adapter.
- Persistent lineage/archive/event database, balanced first-party study assignment, structural visual metrics, and attention-horizon objectives.
- Modular source registry plus generic array-sequence importer for adding future mathematics/biology without rewriting the dashboard.
- Integration boundaries for Paper2Agent, ShinkaEvolve, pyribs, Picbreeder-VLM design patterns, and YouTube metrics.
- Deterministic verification, API/static self-checks, preview generation, reproducible packaging, upstream pins and provenance records.

## 0.3.0 — 2026-09-17
- Real Lenia Orbium trajectory generated from the reference equations + seed.
- Real Chladni/circular membrane eigenmode renderer adapted from MIT upstream mathematics.
- Equation-level Manicka–Levin bioelectric cellular-field simulation with three frozen source variants.
- Provenance-safe NS26 derived source.
- Working specimen-field dashboard, lineage, favorites, event logging, attention niches and For You archive.
- Generic `.npy/.npz` immutable trajectory importer for future papers and biology models.
- Paper2Agent, ShinkaEvolve, pyribs and YouTube experiment bridges.
- Explicit upstream pin file and scientific-core invariants.
