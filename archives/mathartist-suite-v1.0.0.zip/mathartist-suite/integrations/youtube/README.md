# YouTube attention bridge

The first-party dashboard already logs randomized-viewing primitives (`impression`, 5/10/20-second
survival, dwell, fullscreen, favorite, replay) to SQLite. YouTube is a second, observational environment.

Recommended mapping for a rendered fixed-duration organism:

```json
{"video_id":"...","phenotype_id":"bioelectric-...","duration_s":30}
```

Import YouTube Analytics retention as **external observations**, not as proof of rasa/valence. Keep
traffic source, device, publication time and exposure metadata because recommendation/distribution is a confound.

The intended production adapter uses the YouTube Analytics API's elapsed-video-time retention reports.
Do not mix YouTube observational data with the controlled-lab event table without an explicit `environment` field.
