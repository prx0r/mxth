#!/usr/bin/env python3
from __future__ import annotations
import hashlib,json,pathlib,subprocess,sys,tempfile,time,urllib.request
ROOT=pathlib.Path(__file__).resolve().parents[1]

def sha(p):
    h=hashlib.sha256();h.update(p.read_bytes());return h.hexdigest()

def main():
    subprocess.run([sys.executable,str(ROOT/'tests/test_core.py')],check=True,cwd=ROOT)
    # Syntax-check every browser module with Node when present.
    node=__import__('shutil').which('node')
    if node:
        for p in sorted((ROOT/'app/static/js').rglob('*.js')):
            subprocess.run([node,'--check',str(p)],check=True)
    # Deterministic source assets must be present and nontrivial.
    req=[ROOT/'app/static/data/lenia/orbium.u8.bin',
         ROOT/'app/static/data/bioelectric/center-hyperpolarized.f32.bin',
         ROOT/'app/static/data/bioelectric/french-flag.f32.bin']
    for p in req:
        assert p.exists() and p.stat().st_size>1000,p
    # HTTP smoke test on an ephemeral free port.
    import socket
    s=socket.socket();s.bind(('127.0.0.1',0));port=s.getsockname()[1];s.close()
    
    tmpdb=tempfile.TemporaryDirectory(); env=dict(__import__('os').environ); env['MATHARTIST_DB']=str(pathlib.Path(tmpdb.name)/'smoke.sqlite3')
    proc=subprocess.Popen([sys.executable,str(ROOT/'app/server.py'),str(port)],cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,env=env)
    try:
        for _ in range(40):
            try:
                with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/health',timeout=.5) as r:
                    health=json.load(r);break
            except Exception:time.sleep(.05)
        else:raise RuntimeError('server did not start')
        assert health['ok']
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/sources') as r:sources=json.load(r)
        assert {'LENIA','CHLADNI','BIOELECTRIC','NS26'}<= {x['id'] for x in sources}
        with urllib.request.urlopen(f'http://127.0.0.1:{port}/api/population?source=LENIA&mode=open&count=4') as r:pop=json.load(r)
        assert len(pop)==4 and all(x.get('spec_hash') for x in pop)
    finally:
        proc.terminate();proc.wait(timeout=5);tmpdb.cleanup()
    print(json.dumps({'ok':True,'sources':len(sources),'lenia_bytes':req[0].stat().st_size,'bio_bytes':req[1].stat().st_size},indent=2))
if __name__=='__main__':main()
