# MathArtist V1

A strict evolutionary laboratory for mathematical generative artists.

## V1 contract

1. Background is always near-black.
2. Marks are grayscale only.
3. A **Paper Artist** owns the mathematical state/dynamics.
4. Evolution mutates only declared parameters and never silently changes the artist's locked mathematics.
5. Third-party exemplars are references/grammar unless their license permits redistribution.
6. Favorites are explicit human selection pressure.
7. **Evolution** breeds from the currently selected organisms.
8. **For You** continuously samples descendants of favorites for the active artist.
9. Every future paper artist must declare provenance: EXACT / INVARIANT / DERIVED / HYBRID / FREE.

## Run

```bash
npm install
npm run dev
```

Open the local Vite URL.

## Interaction

- Click one or more organisms to select parents.
- `EVOLVE` creates the next generation around those parents.
- `☆` favorites an organism.
- `FOR YOU` generates a larger population around your favorites.
- `FAVORITES` is the persistent collection (localStorage).
- `NEW SEED` explores another deterministic population.

## Architecture

`src/artists.js` — mathematical artists and their legal mutation surfaces  
`src/evolution.js` — seeded mutation engine  
`src/render.js` — deliberately narrow monochrome renderer  
`src/main.js` — gallery, selection, favorites and For You population

## Next strict milestone

Add a paper-ingestion compiler that emits a *candidate* `MathArtistSpec` rather than arbitrary
rendering code. A validator should reject specs without equations, parameter bounds, provenance,
locked invariants, and executable tests. An LLM proposes specs/mutations; the deterministic runtime
remains the authority.
