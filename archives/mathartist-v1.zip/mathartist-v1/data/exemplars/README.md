# Exemplars

V1 deliberately does **not** redistribute third-party artist source.

Store only:
- source URL
- artist
- license
- screenshot/preview only when redistribution permits it
- extracted visual grammar notes

The included `POLAR_CREATURE` is an original synthetic baseline implementing the general
compact-point-mapping grammar: dense point sampling, trigonometric coordinate transforms,
polar projection and phase animation.
