// Strict V1: every artist owns its state mapping. Visual grammar only samples,
 // shades, trails and projects; it does not replace the artist's mathematics.

export const artists = {
  "NS26_CORE": {
    label:"NS26 / similarity core",
    provenance:"derived",
    paper:"OpenAI Navier–Stokes construction, 2026",
    base:{h:.006,tau:.12,twist:1.2,etaFreq:3.0,density:1.0,trail:.16,exposure:.62},
    bounds:{h:[.001,.009],tau:[.008,.55],twist:[.3,3.5],etaFreq:[1,8],density:[.35,1.8],trail:[.02,.5],exposure:[.25,.95]},
    point(i,n,g,time){
      // Similarity scaling retained from the proof-derived construction:
      // radial ~ tau^(1/2), axial ~ tau^(1/2-h), velocity scale ~ tau^(-1/2-h).
      const u=i/n, eta=2*((i*0.61803398875)%1)-1;
      const tau=Math.max(.0005,g.tau*(.72+.28*Math.sin(time*.22+g.etaFreq)));
      const rScale=Math.pow(tau,.5), zScale=Math.pow(tau,.5-g.h);
      const vel=Math.pow(tau,-.5-g.h);
      const X=.05+3.4*((i*0.754877666)%1);
      const r=Math.sqrt(2*tau*X)*rScale*4.4;
      const pulse=Math.sin(g.etaFreq*eta*Math.PI + X*5 - time*vel*.018);
      const theta=2*Math.PI*u*34 + g.twist*vel*.016*time + .55*pulse;
      const z=zScale*eta*5.2 + .12*Math.sin(X*9-time);
      return [r*Math.cos(theta), z, r*Math.sin(theta), .35+.65*Math.abs(pulse)];
    }
  },

  "POLAR_CREATURE": {
    label:"Exemplar / polar creature",
    provenance:"original exemplar grammar",
    paper:"synthetic baseline inspired by compact Processing point mappings",
    base:{lobes:7,fold:4.2,warp:.72,spin:.35,density:1.0,trail:.1,exposure:.65},
    bounds:{lobes:[2,17],fold:[1,9],warp:[.1,1.8],spin:[-.9,.9],density:[.35,1.8],trail:[.02,.5],exposure:[.25,.95]},
    point(i,n,g,time){
      const y=i/n*28-14, k=(4+Math.sin(y))*Math.cos(i/7);
      const e=y/5-1.8, d=Math.hypot(k,e)-1.1;
      const q=1.4+.08*Math.sin(9/(Math.abs(k)+.12))+g.warp*k*(e+Math.sin(-d*g.fold));
      const c=d/g.lobes-time*g.spin+(i%2)*Math.PI;
      return [q*Math.sin(c), q*Math.cos(c), .35*Math.sin(d*2+time), .4+.6*Math.abs(Math.sin(k))];
    }
  }
};