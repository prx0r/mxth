export function rng(seed){
  let s=(seed>>>0)||1;
  return ()=>((s=Math.imul(1664525,s)+1013904223>>>0)/4294967296);
}
export function gaussian(r){
  let u=0,v=0; while(!u)u=r(); while(!v)v=r();
  return Math.sqrt(-2*Math.log(u))*Math.cos(2*Math.PI*v);
}