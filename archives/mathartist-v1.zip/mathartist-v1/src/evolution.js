import {rng,gaussian} from "./rng.js";

export function clamp(x,a,b){return Math.max(a,Math.min(b,x))}
export function makePopulation(artist, seed, generation, parents=[], count=16){
  const R=rng((seed + generation*2654435761)>>>0);
  const source=parents.length?parents:[artist.base];
  return Array.from({length:count},(_,idx)=>{
    const parent=source[Math.floor(R()*source.length)];
    const g={...parent};
    for(const [k,[lo,hi]] of Object.entries(artist.bounds)){
      const span=hi-lo;
      const sigma=parents.length?.055:.12;
      if(k==="lobes") g[k]=Math.round(clamp((g[k]??artist.base[k])+gaussian(R)*span*sigma,lo,hi));
      else g[k]=clamp((g[k]??artist.base[k])+gaussian(R)*span*sigma,lo,hi);
    }
    return {genome:g,id:`G${String(generation).padStart(3,"0")}-${String(idx).padStart(2,"0")}`,
      parent:parents.length?"selected":"root"};
  });
}