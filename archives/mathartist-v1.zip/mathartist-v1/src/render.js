export function render(canvas, artist, genome, time=0){
  const ctx=canvas.getContext("2d");
  const W=canvas.width,H=canvas.height;
  ctx.fillStyle="#050505";ctx.fillRect(0,0,W,H);
  ctx.globalCompositeOperation="lighter";
  const N=Math.floor(11500*genome.density);
  const scale=Math.min(W,H)*.115;
  for(let i=0;i<N;i++){
    const p=artist.point(i,N,genome,time);
    if(!p || !p.every(Number.isFinite))continue;
    const perspective=1/(1+Math.max(-.75,p[2]*.055));
    const x=W/2+p[0]*scale*perspective, y=H/2+p[1]*scale*perspective;
    if(x<0||x>=W||y<0||y>=H)continue;
    const a=Math.max(.025,Math.min(.5,p[3]*genome.exposure*.18));
    const shade=Math.floor(125+125*Math.max(0,Math.min(1,p[3])));
    ctx.fillStyle=`rgba(${shade},${shade},${shade},${a})`;
    ctx.fillRect(x,y,1.15,1.15);
  }
  ctx.globalCompositeOperation="source-over";
}