import {artists} from "./artists.js";
import {makePopulation} from "./evolution.js";
import {render} from "./render.js";

const $=s=>document.querySelector(s), gallery=$("#gallery"), artistSel=$("#artist");
Object.entries(artists).forEach(([k,a])=>artistSel.add(new Option(a.label,k)));
let state=JSON.parse(localStorage.getItem("mathartist-v1")||"null")||{
  artist:"NS26_CORE",seed:260908,generation:0,tab:"evolution",favorites:[],selected:[]
};
let population=[], raf=0, start=performance.now();

function save(){localStorage.setItem("mathartist-v1",JSON.stringify(state))}
function keyOf(x){return `${state.artist}:${JSON.stringify(x.genome)}`}
function favorite(x){return state.favorites.some(f=>f.key===keyOf(x))}
function currentArtist(){return artists[state.artist]}

function regenerate(){
  const parents=state.selected.map(x=>x.genome);
  population=makePopulation(currentArtist(),state.seed,state.generation,parents,16);
  state.selected=[]; save(); drawGallery();
}
function drawGallery(){
  gallery.innerHTML="";
  let items=population;
  if(state.tab==="favorites") items=state.favorites.map((f,i)=>({genome:f.genome,id:f.id||`F-${i}`,parent:f.artist}));
  if(state.tab==="foryou"){
    const favs=state.favorites.filter(f=>f.artist===state.artist).map(f=>f.genome);
    items=makePopulation(currentArtist(),state.seed+99173,state.generation+37,favs,24);
  }
  if(!items.length){gallery.innerHTML='<div class="empty">Nothing here yet.</div>';return}
  const tpl=$("#card-template");
  items.forEach(item=>{
    const node=tpl.content.cloneNode(true), card=node.querySelector(".card"), canvas=node.querySelector("canvas");
    node.querySelector(".id").textContent=item.id;
    node.querySelector(".lineage").textContent=item.parent;
    const fav=node.querySelector(".fav");
    if(favorite(item))fav.classList.add("on"),fav.textContent="★";
    card.onclick=e=>{
      if(e.target===fav)return;
      const k=JSON.stringify(item.genome), idx=state.selected.findIndex(x=>JSON.stringify(x.genome)===k);
      if(idx>=0){state.selected.splice(idx,1);card.classList.remove("selected")}
      else {state.selected.push(item);card.classList.add("selected")}
      save();
    };
    fav.onclick=()=>{
      const k=keyOf(item), idx=state.favorites.findIndex(f=>f.key===k);
      if(idx>=0)state.favorites.splice(idx,1);
      else state.favorites.push({key:k,artist:state.artist,genome:item.genome,id:item.id});
      save();drawGallery();
    };
    gallery.appendChild(node);
    item.canvas=canvas;
  });
}
function animate(now){
  const t=(now-start)/1000;
  [...gallery.querySelectorAll(".card")].forEach((card,i)=>{
    const items=state.tab==="favorites"?state.favorites.map(f=>({genome:f.genome,artist:f.artist})):population;
    const item=items[i]; if(!item)return;
    const a=state.tab==="favorites"?artists[item.artist]:currentArtist();
    render(card.querySelector("canvas"),a,item.genome,t);
  });
  raf=requestAnimationFrame(animate);
}

artistSel.value=state.artist;$("#seed").value=state.seed;$("#generation").textContent=state.generation;
artistSel.onchange=()=>{state.artist=artistSel.value;state.generation=0;regenerate()};
$("#evolve").onclick=()=>{state.generation++;$("#generation").textContent=state.generation;regenerate()};
$("#surprise").onclick=()=>{state.seed=Math.floor(Math.random()*1e9);$("#seed").value=state.seed;state.generation=0;$("#generation").textContent=0;regenerate()};
$("#reset").onclick=()=>{state.generation=0;state.selected=[];$("#generation").textContent=0;regenerate()};
$("#seed").onchange=e=>{state.seed=+e.target.value||1;state.generation=0;regenerate()};
document.querySelectorAll(".tab").forEach(b=>b.onclick=()=>{
  state.tab=b.dataset.tab;document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x===b));save();drawGallery();
});
document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("active",x.dataset.tab===state.tab));
regenerate(); cancelAnimationFrame(raf); animate(performance.now());
