import importlib.util, pathlib, json, tempfile, subprocess, sys
ROOT=pathlib.Path(__file__).resolve().parents[1]
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
def test_candidate_extractor_separates_canvas_constants():
 m=load('ecc',ROOT/'tools/extract_control_candidates.py')
 xs=m.extract("t=0;draw=_=>{createCanvas(400,400);for(i=1e4;i--;)point(99*sin(i/40),200)}")
 assert any(x['role']=='observer_or_runtime' and x['literal']=='400' for x in xs)
 assert any(x['role']=='math_candidate' and x['literal']=='99' for x in xs)
def test_ingest_normalizes_and_hashes():
 m=load('ing',ROOT/'tools/ingest_tsubuyaki.py');x=m.normalize({'artist':'ア','code':'point(1,2)','tweet_url':'https://x.test/1'})
 assert x['artist']=='ア' and len(x['code_sha256'])==64 and x['original_url']
