#!/usr/bin/env python3
"""Fetch an attribution-forward #つぶやきProcessing JSON feed into a local seed registry.
Network access is intentionally runtime-only; third-party code is not vendored into MathArtist releases.
"""
from __future__ import annotations
import argparse, hashlib, json, pathlib, urllib.request

def sha(s:str)->str:return hashlib.sha256(s.encode()).hexdigest()
def normalize(item):
    code=item.get('code') or item.get('source') or item.get('sketch') or ''
    artist=item.get('artist') or item.get('username') or item.get('author') or 'unknown'
    original=item.get('original_url') or item.get('tweet_url') or item.get('url')
    return {'artist':artist,'original_url':original,'archive_url':item.get('archive_url') or item.get('page_url'),
            'language':item.get('language') or 'p5.js','code':code,'code_sha256':sha(code) if code else None,
            'redistribution_status':item.get('license') or 'unknown','source_record':item}
def main():
 p=argparse.ArgumentParser();p.add_argument('--url',default='https://tsubuyaki.art/data/latest.json');p.add_argument('--input');p.add_argument('--out',default='corpus/tsubuyaki/local_registry.jsonl');a=p.parse_args()
 if a.input:data=json.loads(pathlib.Path(a.input).read_text())
 else:
  with urllib.request.urlopen(a.url,timeout=30) as r:data=json.load(r)
 items=data if isinstance(data,list) else data.get('items') or data.get('sketches') or data.get('entries') or []
 out=pathlib.Path(a.out);out.parent.mkdir(parents=True,exist_ok=True)
 with out.open('w') as f:
  for x in items:f.write(json.dumps(normalize(x),ensure_ascii=False)+'\n')
 print(json.dumps({'records':len(items),'out':str(out)}))
if __name__=='__main__':main()
