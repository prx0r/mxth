# V3.3.0
- Converts the #つぶやきProcessing plan from a link manifest into an executable local corpus-ingestion path.
- Adds attribution/hash-preserving feed normalization.
- Adds conservative numeric control-candidate extraction with observer/runtime separation.
- Adds explicit 25-seed × 1,000-descendant acceptance benchmark.
- Freezes the dumb-high-volume / human-POTENTIAL division as a protocol.
- Adds coding-agent instructions focused on data rather than architecture.
