# MathArtist V3.2 Resource Megapack

Purpose: turn MathArtist into a deliberately dumb, high-volume emergence laboratory.

Core loop:

`real seed M + legitimate controls Θ -> massive blind parameter search -> minimal observation -> morphology coverage -> human POTENTIAL -> local branch explosion -> repeat`

The machine must not learn "beauty" in OPEN. Human selections are experimental observations and branch instructions, not an objective function.

Start with `docs/DEV_AGENT_INSTRUCTIONS.md`, then run `scripts/fetch_all_repos.sh` on an internet-connected machine to materialize the repository corpus.

This pack includes the current MathArtist V3.2 release plus a reproducible resource manifest. Third-party repositories are fetched from their canonical upstreams rather than silently vendored without preserving their license/history.
