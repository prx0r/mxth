# DEV AGENT INSTRUCTIONS — MathArtist V3.3 data-first build

## Mission
Do not redesign the architecture. V3.2 is the base. The job is to feed it excellent mathematical/scientific seeds and prove that dumb high-volume search can discover surprising phenotypes.

## Non-negotiable invariant
An Artist is `(M, Θ, O)`:
- `M`: immutable executable mathematical/scientific mechanism.
- `Θ`: only legitimate source-defined degrees of freedom, each with provenance.
- `O`: minimal observer. Prefer points, lines, trajectories, contours, scalar threshold, or source-native geometry.

Never mutate fixed equations merely to make prettier output. Never add arbitrary glow/color/camera/effects to rescue weak mathematics. If a source has no legitimate fertile control surface, mark it unsuitable.

## Search philosophy
OPEN is intentionally dumb. Use random/Sobol/LHS sampling, local mutation, categorical branch mutation, and occasional random roots. Preserve all viable lineage metadata. Technical integrity gates may reject NaN/blank/broken renders; they must not encode composition or beauty.

Do not train a beauty model. Morphology embeddings may be used only to avoid showing near-duplicates and to maintain coverage. Human `POTENTIAL` is separate from OPEN.

When the human selects POTENTIAL at θ*, spawn a configurable local cloud around θ* (default 1k, scalable to 10k+) with several mutation radii. Preserve parent-child lineage and exact seed/control provenance.

## Phase 1 — #つぶやきProcessing benchmark corpus
1. Use the official portal/archive/resources in `manifests/sites.csv`.
2. Prioritize curated/high-signal creators and examples, especially ア / @yuruyurau, Hau_kun roundups, NEORT picks, and other compact p5.js mechanisms.
3. Respect source licenses/attribution/removal requests. Do not redistribute code without permission/license. Where code cannot be vendored, store URL, author, post ID, preview hash, mechanism notes, and a local adapter created independently.
4. For each runnable seed, first reproduce its canonical phenotype exactly enough to establish fidelity.
5. Expand minified code into a readable AST/IR only for analysis. Preserve the original source bytes/hash separately.
6. Extract candidate numeric/enum controls. Classify each as: mathematical control, time/sampling control, rendering-only, fixed literal, or unsafe/unknown.
7. Only mathematical and legitimate sampling/time controls enter Θ. Every control requires source evidence or a clearly documented syntactic role.
8. Sweep each accepted seed at volume. Start 1k specimens/seed; promote fertile seeds to 10k–100k.
9. Compute technical validity + morphology embeddings + lineage. Do not score beauty.
10. Produce contact sheets/fast gallery streams for human POTENTIAL selection.

## Fertility
Measure seed fertility as diversity/coverage of viable descendants, not mean attractiveness. Record multiple mutation radii. A seed that has one beautiful default but a dead parameter neighborhood is less useful than one with many distinct regimes.

Suggested outputs per seed:
- exact source/provenance record
- control-surface schema
- canonical reproduction test
- 1k blind sweep
- embedding/descriptor coverage
- duplicate rate
- technical failure rate
- lineage graph
- representative contact sheet
- fertility report

## Phase 2 — open-ended lineage
Use Sakana/Picbreeder as design evidence for archive/branching/stepping stones, NOT as the genotype. MathArtist genotype remains the real source mechanism + controls. Preserve random roots and weird stepping stones. Do not let a VLM steer OPEN toward named objects.

## Phase 3 — science seeds
After the Processing benchmark works, apply the same interface to:
- Lenia / SmoothLife / Physarum / differential growth
- bioelectric/developmental models (BETSE / Levin-adjacent executable work)
- cymatics/eigenmodes
- fluid dynamics and eventually the exact Navier–Stokes construction
- protein/biology systems such as AlphaFold only where controls are legitimate and scientifically interpretable
- formal mathematics via Paper2Agent + AXLE/Axiom where an executable family can actually be extracted

For papers: Paper2Agent should reproduce source tutorials/functions first. MathArtist then identifies a control surface. Do not force a proof with no executable family into an Artist.

## Human experiment layer
Keep generation and measurement separate. Log human behavior: exposure, dwell, replay, POTENTIAL, BEAUTIFUL if enabled, branch, favorite. Do not reveal QRI/rasa descriptors before selection in blinded studies.

Compute downstream structural descriptors (symmetry, symmetry dynamics, spectral entropy, recurrence, compressibility/coherence etc.) as hypotheses only. Rasa/Abhinavagupta responses are retrospective phenomenological labels, not generation targets. Valence, attention, absorption, wonder and liking must remain separate variables.

Discovery -> freeze hypothesis -> preregister -> fresh specimens/fresh humans -> confirmation -> replication. Never claim a QRI/rasa relationship from the same adaptive data used to discover it.

## Acceptance gates
A release is not complete because tests pass. It needs empirical artifacts:
1. clean-room unpack + unit tests
2. HTTP/API smoke test
3. canonical source reproduction tests
4. >=100 real external seeds indexed, >=25 runnable/fidelity-tested for first milestone
5. >=1k blind descendants per runnable seed
6. contact sheets from actual outputs
7. human POTENTIAL branching works end-to-end
8. no preference leakage into OPEN (regression test)
9. exact source/control/lineage reproducibility
10. explicit list of what is DERIVED vs EXACT.

## First concrete target
Do not add architecture until this benchmark exists: 25 excellent tweet-sized Processing seeds x 1,000 blind descendants = 25,000 specimens. Review fertility. Then scale to 100 seeds and 100k+ specimens.
