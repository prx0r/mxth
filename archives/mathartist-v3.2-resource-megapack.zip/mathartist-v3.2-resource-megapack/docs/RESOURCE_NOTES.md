# Resource notes

The #つぶやきProcessing corpus is the first benchmark, not aesthetic training data. Its value is that thousands of humans independently compressed fertile visual mathematics into tiny executable programs. Treat each program as a candidate mechanism, preserve authorship, and explore only legitimate controls.

Skepara is especially relevant because it already demonstrates automatic extraction of numeric literals from tiny p5.js sketches into sliders. MathArtist should go further by classifying which extracted literals are mathematical controls versus rendering/fixed literals.

Sakana/Picbreeder supplies the archive/branching/stepping-stone precedent. Preserve the key lesson: artifacts can appear as objectives-in-retrospect. Do not adopt CPPNs as MathArtist's scientific genotype.

Paper2Agent supplies the verified paper-to-executable bridge. Its verifier/improver approach should inspire exact reproduction gates before a scientific source is admitted.

AXLE/Axiom is useful for formal verification and declaration extraction, but formal proofs only become MathArtist seeds when they expose an executable family/control surface. Never force a theorem into a visual generator.
