#!/usr/bin/env bash
set -euo pipefail
for z in "$@"; do
  echo "== $z =="
  unzip -t "$z" >/dev/null && echo ZIP_OK
  sha256sum "$z"
done
