#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")/.." && pwd)"
DEST="${1:-$HERE/upstreams}"
mkdir -p "$DEST"
python3 - "$HERE/manifests/repos.csv" "$DEST" <<'PY'
import csv, subprocess, pathlib, sys
manifest, dest = sys.argv[1], pathlib.Path(sys.argv[2])
with open(manifest, newline='', encoding='utf-8') as f:
    for r in csv.DictReader(f):
        url=r['url']; name=r['name'].replace('/','_')
        out=dest/name
        if out.exists():
            print('SKIP',name)
            continue
        print('CLONE',name,url)
        subprocess.run(['git','clone','--depth','1',url,str(out)],check=False)
print('Done. Review every upstream LICENSE before redistribution.')
PY
