from __future__ import annotations
import json,math


def _distance(spec,a,b):
    acc=[]
    for k,d in spec.get('interpretation_genes',{}).items():
        av=a.get(k);bv=b.get(k)
        if av is None or bv is None:continue
        if d['type'] in ('float','int'):
            span=max(1e-12,float(d['max'])-float(d['min']));acc.append(((float(av)-float(bv))/span)**2)
        elif d['type']=='enum':acc.append(0 if av==bv else 1)
    return math.sqrt(sum(acc)/max(1,len(acc)))


def sakana_archive_parent_ids(c,source_id,spec,rng,limit=60):
    """Shared-archive sampler inspired by Picbreeder-VLM's ecology.

    Mixes recency, public rating proxies, branching popularity, genotype diversity and random
    stepping stones. It deliberately leaves a stochastic component so the archive does not
    converge on one aesthetic attractor. This is a local compatible sampler, not copied Sakana code.
    """
    rows=c.execute('SELECT id,genome_json,created_at FROM phenotypes WHERE source_id=? ORDER BY created_at DESC LIMIT 1200',(source_id,)).fetchall()
    if not rows:return []
    items=[{'id':r['id'],'g':json.loads(r['genome_json']),'created_at':r['created_at']} for r in rows]
    ids=[x['id'] for x in items]
    branch={pid:c.execute('SELECT COUNT(*) FROM phenotypes WHERE parent_ids LIKE ?',(f'%"{pid}"%',)).fetchone()[0] for pid in ids}
    rating={}
    for pid in ids:
        e=c.execute("SELECT event_type,COUNT(*) n,COALESCE(SUM(value),0) v FROM events WHERE phenotype_id=? GROUP BY event_type",(pid,)).fetchall()
        m={r['event_type']:(r['n'],r['v']) for r in e};imp=max(1,m.get('impression',(0,0))[0])
        viability=m.get('viability',(0,0))
        viability_rate=(viability[1]/max(1,viability[0])) if viability[0] else 1.0
        rating[pid]=(2.2*m.get('favorite',(0,0))[0]/imp+.6*m.get('fullscreen',(0,0))[0]/imp+
                     min(1.0,m.get('dwell',(0,0))[1]/(imp*20000))) * (0.12 + 0.88*viability_rate)
    recent=[x['id'] for x in items[:16]]
    rated=sorted(ids,key=lambda x:rating[x],reverse=True)[:16]
    branchy=sorted(ids,key=lambda x:branch[x],reverse=True)[:16]
    # Greedy farthest-point sample in interpretation-genome space.
    byid={x['id']:x for x in items};diverse=[]
    seed=rng.choice(ids);diverse=[seed]
    pool=set(ids)-{seed}
    while pool and len(diverse)<16:
        nxt=max(pool,key=lambda pid:min(_distance(spec,byid[pid]['g'],byid[q]['g']) for q in diverse))
        diverse.append(nxt);pool.remove(nxt)
    randoms=rng.sample(ids,min(16,len(ids)))
    ordered=[];seen=set()
    streams=[recent,rated,branchy,diverse,randoms]
    # Interleave instead of exhausting one source first.
    for i in range(max(map(len,streams))):
        for stream in streams:
            if i<len(stream) and stream[i] not in seen:
                seen.add(stream[i]);ordered.append(stream[i])
                if len(ordered)>=limit:return ordered
    return ordered
