# Changelog

## 0.3.0 — 2026-09-17
- Real Lenia Orbium trajectory generated from the reference equations + seed.
- Real Chladni/circular membrane eigenmode renderer adapted from MIT upstream mathematics.
- Equation-level Manicka–Levin bioelectric cellular-field simulation with three frozen source variants.
- Provenance-safe NS26 derived source.
- Working specimen-field dashboard, lineage, favorites, event logging, attention niches and For You archive.
- Generic `.npy/.npz` immutable trajectory importer for future papers and biology models.
- Paper2Agent, ShinkaEvolve, pyribs and YouTube experiment bridges.
- Explicit upstream pin file and scientific-core invariants.
