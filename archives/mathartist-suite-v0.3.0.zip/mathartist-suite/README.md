# MathArtist Lab 0.3 — immutable science, evolving perception

A runnable research/art system for turning mathematical and scientific objects into evolving visual
"artists" **without evolving the underlying science**.

```text
paper / theorem / biological model
            ↓
     immutable source state
            ↓
    interpretation genome
            ↓
 monochrome living phenotype
            ↓
 open archive / human taste / attention experiments
```

## Run

```bash
./run.sh
# open http://127.0.0.1:8765
```

Core runtime: Python 3 + a modern browser. No npm install and no database server.

## What is genuinely working

- Specimen-field dashboard based on the supplied visual reference: near-black field, minimal chrome,
  dense living monochrome organisms, fullscreen inspection, lineage and favorites.
- **Lenia Orbium** trajectory generated from Bert Chan's reference Lenia equations, exact Orbium seed
  and parameters; source trajectory is shared/frozen while views evolve.
- **Chladni / circular membrane cymatics** using the actual Bessel/eigenmode mathematics adapted from
  Olivier Giulieri's MIT project.
- **Manicka–Levin bioelectric morphogenesis** equation-level source trajectories: Vmem, extracellular
  field, field vectors and current are available as distinct immutable observables.
- **NS26** similarity artist explicitly marked DERIVED until an executable full-paper adapter replaces it.
- Selection, crossover/mutation of interpretation genes, lineage, archive branching and random stepping-
  stone injection inspired by Sakana AI Picbreeder-VLM.
- Persistent SQLite event stream: impressions, 5s/10s/20s survival, dwell, fullscreen, favorite, replay.
- Separate OPEN and FOR YOU search; public attention niches can breed from observed behavior.
- Structural readout in fullscreen: approximate symmetry, image entropy, occupancy and edge complexity.
- Generic `.npy/.npz` importer: a new paper/model can become a dashboard source without editing the UI.
- Optional bridges for Paper2Agent, ShinkaEvolve, pyribs and YouTube observational metrics.
- Immutable-core SHA-256 stored in every lineage; if a scientific core changes, the old lineage refuses
  to continue silently.

## Reuse instead of rewriting

Pinned upstream revisions are recorded in `UPSTREAMS.lock.json`.

- **Lenia** — reference equations/seed from `Chakazul/Lenia` (MIT).
- **Cymatics** — Bessel/eigenmode mathematics from `evoluteur/cymatics` (MIT).
- **Sakana AI Picbreeder-VLM** — archive/phylogeny/stepping-stone search design.
- **ShinkaEvolve** — optional program-evolution proposer for interpretation code only; scientific core
  protected by a hash verifier.
- **pyribs** — optional quality-diversity/MAP-Elites backend rather than recreating CMA-ME/CMA-MAE.
- **Paper2Agent** — preferred paper/code/supplement ingestion layer.
- **ElectricMorphogenesis** — real developmental-bioelectric model lineage / future pretrained runtime.

A networked development machine can run `scripts/vendor_upstreams.sh` to clone these repositories under
`external/` (gitignored). The suite itself contains only the adapted pieces and provenance/licenses it
needs, keeping the ZIP small and authorship clear.

## Add a new paper or biological model

Fast route:

```bash
python scripts/import_array_sequence.py run.npy \
  --id NEWPAPER26 \
  --title "New Paper / invariant field" \
  --fps 12 \
  --provenance-level EXACT-DATA
```

Accepted shapes: `T×H×W`, `T×H×W×C`, or `T×N` where `N` is square. The source bytes are hashed; the
browser gets a display-quantized immutable copy; evolution changes only observation genes.

For papers with code/supplements, use Paper2Agent first, validate its executable observable manifest,
then export the source trajectory. See `docs/SOURCE_PLUGIN.md`.

## Search / experiment model

`FRONTIER` — fresh/random interpretations.

`OPEN` — lineage/stepping-stone archive; no user-taste objective required.

`5s / 10s / 20s / REPLAY` — separate behavioral niches. The longer horizons are conditional where
possible so a 5-second hook does not automatically dominate later absorption.

`FOR YOU` — session-local favorites + dwell + fullscreen signal, with exploration preserved.

`FAVORITES` — explicit human archive.

Do not interpret these as measurements of rasa or valence. `experiments/RASA_QRI.md` treats
Abhinavagupta and QRI-inspired structural claims as hypotheses to test, not truths baked into the optimizer.

## Rebuild deterministic source trajectories

```bash
python tools/generate_trajectories.py
```

## Verify before continuing development

```bash
python scripts/verify_suite.py
```

Then read `docs/DEVELOPMENT.md`. The repo is intentionally organized so a future coding agent can open
this ZIP and continue from the existing source adapters, archive and dashboard instead of rebuilding it.
