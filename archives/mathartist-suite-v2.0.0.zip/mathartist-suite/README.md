# MathArtist Suite V2 — immutable science, evolving perception

A modular research/art laboratory where a theorem, simulation or biological model is a fixed **scientific artist**, while evolution searches only ways of observing it.

```text
frontier paper/model -> validated executable source -> cryptographic SourceBundle
                                               |
                                               v
                                      interpretation genome
                                               |
                                               v
                                         living phenotype
                                               |
                 +-----------------------------+-----------------------------+
                 |                             |                             |
              OPEN/QD                     controlled LAB                 YouTube WILD
           stepping stones          attention + valence + rasa        retention/replay
```

## Run

```bash
./run.sh
# http://127.0.0.1:8765
```

Core runtime requires only Python 3 and a modern browser. Optional research integrations are isolated.

## What V2 adds

### 1. SourceBundle immutability

V1 hashed immutable metadata. V2 hashes the actual files that causally define each source variant: trajectory bytes, runtime/renderer source, licenses/provenance and pinned upstream commit metadata.

```bash
make bundles
```

Manifests live in `bundles/`. A descendant cannot silently continue if the bundle hash changed.

### 2. Real paper -> MathArtist handoff

Use upstream Paper2Agent to generate/verify a scientific agent, then:

```bash
python -m paper2artist.cli inspect /path/to/project-agent --out inspection.json
python -m paper2artist.cli register paper2artist-manifest.json
```

`paper2artist` fingerprints the delivered agent, discovers MCP-facing functions, copies exported scientific arrays into immutable source artifacts and registers them with the generic renderer. See `paper2artist/README.md`.

### 3. Better open-ended archive search

OPEN mode now mixes five parent streams inspired by Sakana/Picbreeder-VLM's shared archive ecology:
recency, human/public rating proxies, branch popularity, interpretation-genome diversity and random stepping stones. Root/noise injection remains explicit to resist aesthetic collapse.

Actual Sakana `ShinkaEvolve` remains an **optional program-level backend** for evolving observation code under a source-hash verifier; continuous parameters stay cheaper in the local archive / optional pyribs backend.

### 4. Formal human-aesthetics experiment layer

The first-party LAB records attention separately from:

- valence
- arousal
- absorption
- favorite/replay/return behavior
- retrospective rasa-category response

The UI does not reveal rasa categories until the viewer elects to respond after viewing. These are measurements/hypotheses, never optimizer definitions of beauty.

Experiment definitions are versioned JSON in `experiments/registry/`.

### 5. YouTube as wild feedback

YouTube is treated as observational ecological replication, not randomized evidence.

```bash
pip install -r requirements-research.txt
export MATHARTIST_YOUTUBE_CLIENT_SECRET=/secure/client_secret.json
python integrations/youtube/youtube_worker.py auth
python integrations/youtube/youtube_worker.py upload organism.mp4 --phenotype PHENOTYPE_ID
python integrations/youtube/youtube_worker.py sync VIDEO_ID --start 2026-09-01 --end 2026-09-30
```

Retention is decomposed into 5-second attention, 10|5 and 20|10 conditional holding, plus replay-area. It is never labelled as rasa.

### 6. Canonical video export

Install Node helper once:

```bash
npm install
python tools/render_video.py PHENOTYPE_ID --out organism.mp4 --seconds 30 --fps 10
```

This imports the same JS source renderers used by the dashboard via `skia-canvas`, then encodes with ffmpeg.

## Current built-in scientific artists

- `LENIA` — exact reference Orbium runtime/trajectory.
- `CHLADNI` — actual Chladni/Bessel eigenmode mathematics.
- `BIOELECTRIC` — equation-level Manicka–Levin cellular-field reimplementation with fixed trajectories.
- `NS26` — intentionally labelled **DERIVED** until replaced by a fuller executable paper adapter.

## Add frontier mathematics

Preferred pipeline:

```text
paper + supplements + repo
        -> Paper2Agent
        -> verified MCP/skill workflow
        -> execute genuine paper observable
        -> export .npy/.npz trajectory/state sequence
        -> paper2artist register
        -> SourceBundle hash
        -> OPEN search / LAB study / YouTube replication
```

If a paper has no executable implementation, register it honestly as `EXACT-EQUATIONS` after an independently validated implementation, or `DERIVED` if only a mechanism/ratio is being represented.

For a direct numerical trajectory without Paper2Agent:

```bash
python scripts/import_array_sequence.py run.npy --id PAPER26_FIELD --title "Paper 2026 / field"
```

## Continue development

Start with **`docs/CONTINUE_HERE.md`**. It defines the interfaces future ZIPs should extend rather than replace.

## Verification

```bash
python scripts/verify_suite.py
```

The package is designed so each later ZIP can copy this repository forward, add migrations/adapters/tests, and retain all prior source lineages and experiment data.
