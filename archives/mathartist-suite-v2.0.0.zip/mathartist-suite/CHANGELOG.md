# Changelog

## 2.0.0 — 2026-09-17

- Rebuilt scientific identity around **SourceBundle SHA-256**, hashing actual trajectory/runtime/render-source bytes plus immutable metadata and upstream commit provenance.
- Lineages now refuse to continue if frozen source bytes change.
- Added `paper2artist`: deterministic inspection/fingerprinting of Paper2Agent outputs and a registration bridge for validated `.npy/.npz` observables.
- Replaced the simple OPEN parent sampler with a Sakana/Picbreeder-VLM-inspired shared-archive explorer mixing recency, ratings, branch popularity, genotype diversity and random stepping stones.
- Added formal experiment registry and DB support for separate valence, arousal, absorption and retrospective rasa-category responses.
- Dashboard now hides aesthetic questions until the viewer explicitly chooses to respond, reducing priming.
- Added YouTube OAuth/upload/Analytics worker and persistent per-video retention storage/fitness decomposition.
- Added exact-browser-render video exporter (`tools/render_video.py` + `render_frames.cjs`) for canonical 30-second experiment clips.
- Added `docs/CONTINUE_HERE.md` as the stable development handoff contract.
- Preserved all V1 sources, archive, renderers, studies, provenance and generic array importer.

## 1.0.0

See V1 ZIP / prior changelog.
