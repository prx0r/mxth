from __future__ import annotations
import json,time,math
from pathlib import Path
from archive import conn

ROOT=Path(__file__).resolve().parents[1]
REGISTRY=ROOT/'experiments'/'registry'


def init_experiment_db():
    with conn() as c:
        c.executescript('''
        CREATE TABLE IF NOT EXISTS experiment_responses(
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          experiment_id TEXT NOT NULL,
          phenotype_id TEXT NOT NULL,
          session_id TEXT NOT NULL,
          valence REAL,
          arousal REAL,
          absorption REAL,
          rasa_label TEXT,
          free_text TEXT,
          metadata_json TEXT NOT NULL,
          created_at REAL NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_exp_resp ON experiment_responses(experiment_id,phenotype_id,created_at);
        CREATE TABLE IF NOT EXISTS youtube_videos(
          video_id TEXT PRIMARY KEY,
          phenotype_id TEXT NOT NULL,
          experiment_id TEXT NOT NULL,
          duration_s REAL,
          published_at REAL,
          metadata_json TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_yt_pheno ON youtube_videos(phenotype_id,experiment_id);
        CREATE TABLE IF NOT EXISTS youtube_retention(
          video_id TEXT NOT NULL,
          elapsed_ratio REAL NOT NULL,
          audience_watch_ratio REAL,
          relative_retention REAL,
          started_watching REAL,
          stopped_watching REAL,
          segment_impressions REAL,
          fetched_at REAL NOT NULL,
          PRIMARY KEY(video_id,elapsed_ratio)
        );
        ''')


def list_experiments():
    out=[]
    if not REGISTRY.exists(): return out
    for p in sorted(REGISTRY.glob('*.json')):
        x=json.loads(p.read_text());x['_file']=p.name;out.append(x)
    return out


def get_experiment(exp_id:str):
    for x in list_experiments():
        if x.get('id')==exp_id:return x
    return None


def add_response(payload:dict):
    exp=payload.get('experiment_id','attention-rasa-v2')
    if not get_experiment(exp): raise KeyError(f'unknown experiment: {exp}')
    def bounded(name,lo=-1,hi=1):
        v=payload.get(name)
        if v is None:return None
        v=float(v);return max(lo,min(hi,v))
    with conn() as c:
        c.execute('''INSERT INTO experiment_responses(
          experiment_id,phenotype_id,session_id,valence,arousal,absorption,rasa_label,free_text,metadata_json,created_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?)''',(
          exp,payload.get('phenotype_id',''),payload.get('session_id','anon'),
          bounded('valence'),bounded('arousal'),bounded('absorption'),
          payload.get('rasa_label'),payload.get('free_text','')[:2000],json.dumps(payload.get('metadata',{})),time.time()
        ))


def register_youtube_video(video_id, phenotype_id, experiment_id='youtube-attention-v2', duration_s=None, metadata=None):
    with conn() as c:
        c.execute('''INSERT INTO youtube_videos(video_id,phenotype_id,experiment_id,duration_s,published_at,metadata_json)
        VALUES(?,?,?,?,?,?) ON CONFLICT(video_id) DO UPDATE SET phenotype_id=excluded.phenotype_id,
        experiment_id=excluded.experiment_id,duration_s=excluded.duration_s,metadata_json=excluded.metadata_json''',
        (video_id,phenotype_id,experiment_id,duration_s,time.time(),json.dumps(metadata or {})))


def upsert_retention(video_id, rows:list[dict]):
    now=time.time()
    with conn() as c:
        for r in rows:
            c.execute('''INSERT INTO youtube_retention(video_id,elapsed_ratio,audience_watch_ratio,relative_retention,
              started_watching,stopped_watching,segment_impressions,fetched_at) VALUES(?,?,?,?,?,?,?,?)
              ON CONFLICT(video_id,elapsed_ratio) DO UPDATE SET audience_watch_ratio=excluded.audience_watch_ratio,
              relative_retention=excluded.relative_retention,started_watching=excluded.started_watching,
              stopped_watching=excluded.stopped_watching,segment_impressions=excluded.segment_impressions,
              fetched_at=excluded.fetched_at''',(
              video_id,float(r['elapsedVideoTimeRatio']),_f(r.get('audienceWatchRatio')),_f(r.get('relativeRetentionPerformance')),
              _f(r.get('startedWatching')),_f(r.get('stoppedWatching')),_f(r.get('totalSegmentImpressions')),now))


def _f(x):
    try:return None if x is None else float(x)
    except:return None


def _nearest(rows, target):
    if not rows:return None
    return min(rows,key=lambda r:abs(float(r['elapsed_ratio'])-target))


def youtube_fitness(video_id:str):
    with conn() as c:
        v=c.execute('SELECT * FROM youtube_videos WHERE video_id=?',(video_id,)).fetchone()
        rows=[dict(r) for r in c.execute('SELECT * FROM youtube_retention WHERE video_id=? ORDER BY elapsed_ratio',(video_id,))]
    if not v or not rows:return None
    dur=float(v['duration_s'] or 30.0)
    def awr(sec):
        r=_nearest(rows,max(0,min(1,sec/dur)));return None if not r else r.get('audience_watch_ratio')
    a5,a10,a20=awr(5),awr(10),awr(20)
    replay=sum(max(0,(r.get('audience_watch_ratio') or 0)-1) for r in rows)/max(1,len(rows))
    return {
      'video_id':video_id,'phenotype_id':v['phenotype_id'],'duration_s':dur,
      'awr_5s':a5,'awr_10s':a10,'awr_20s':a20,
      'hold_10_given_5':None if not a5 or a10 is None else a10/a5,
      'hold_20_given_10':None if not a10 or a20 is None else a20/a10,
      'replay_area':replay,'points':len(rows)
    }


def experiment_report(exp_id='attention-rasa-v2'):
    with conn() as c:
        rr=[dict(r) for r in c.execute('SELECT * FROM experiment_responses WHERE experiment_id=?',(exp_id,))]
        vids=[r[0] for r in c.execute('SELECT video_id FROM youtube_videos WHERE experiment_id=?',(exp_id,))]
    vals=[r['valence'] for r in rr if r['valence'] is not None]
    absor=[r['absorption'] for r in rr if r['absorption'] is not None]
    labels={}
    for r in rr:
        if r['rasa_label']:labels[r['rasa_label']]=labels.get(r['rasa_label'],0)+1
    return {
      'experiment_id':exp_id,'n_responses':len(rr),'mean_valence':_mean(vals),'mean_absorption':_mean(absor),
      'rasa_labels':labels,'youtube':[x for x in (youtube_fitness(v) for v in vids) if x]
    }


def _mean(xs):return None if not xs else sum(xs)/len(xs)
