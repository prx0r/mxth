# Control Surface — V3 core

V3 deliberately makes the search loop dumber. A source is an executable mathematical/scientific family `M(theta)`. The genome is `theta`: only controls that the paper, code, experiment or model actually admits.

Each native control records `role`, `claim_scope`, and `provenance`. The engine mutates numbers/enums; it does not invent equations. `observation-only` and `numerical-only` controls are allowed but must remain labelled separately from same-family scientific controls.

AI belongs at ingestion time: inspect the paper/repo, propose candidate controls, attach evidence, and freeze the reviewed surface. The hot evolutionary loop is ordinary stochastic parameter search.
