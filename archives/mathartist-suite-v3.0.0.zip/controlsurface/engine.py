from __future__ import annotations
import math

SAFE_ROLES={"family","initial_condition","boundary_condition","phase","time","scale","seed","branch","sampling","numerical"}

def surface_for_spec(spec):
    """V3 native `control_surface`, with V2 observation genes as a compatibility fallback."""
    if spec.get("control_surface"):
        return spec["control_surface"]
    return spec.get("interpretation_genes",{})

def validate_control_surface(spec):
    errors=[]
    for name,d in surface_for_spec(spec).items():
        if d.get("type") not in {"float","int","enum"}: errors.append(f"{name}: unsupported type")
        if spec.get("control_surface"):
            if not d.get("provenance"): errors.append(f"{name}: missing provenance")
            if d.get("role") not in SAFE_ROLES: errors.append(f"{name}: invalid role")
            if d.get("claim_scope") not in {"same-family","observation-only","numerical-only"}: errors.append(f"{name}: invalid claim_scope")
    return errors

def _clamp(x,lo,hi): return max(lo,min(hi,x))

def _sample_one(d,rng):
    typ=d["type"]
    if typ=="enum":
        vals=d["values"]; default=d.get("default")
        return default if default in vals and rng.random()<.45 else rng.choice(vals)
    lo,hi=d["min"],d["max"]
    default=d.get("default",(lo+hi)/2)
    if d.get("mutation")=="log" and lo>0:
        return math.exp(rng.uniform(math.log(lo),math.log(hi))) if rng.random()<.3 else _clamp(default*math.exp(rng.gauss(0,d.get("sigma",.18))),lo,hi)
    if typ=="int": return rng.randint(int(lo),int(hi)) if rng.random()<.3 else int(_clamp(round(default+rng.gauss(0,d.get("sigma",1))),lo,hi))
    return rng.uniform(lo,hi) if rng.random()<.3 else _clamp(default+rng.gauss(0,d.get("sigma",(hi-lo)*.12)),lo,hi)

def random_controls(spec,rng):
    return {k:_sample_one(d,rng) for k,d in surface_for_spec(spec).items()}

def mutate_controls(spec,parent,rng,strength=1.0):
    surface=surface_for_spec(spec); g=dict(parent); touched=0
    for name,d in surface.items():
        if rng.random()>min(.9,.28*strength): continue
        touched+=1; typ=d["type"]
        if typ=="enum":
            vals=[v for v in d["values"] if v!=g.get(name)]
            if vals:g[name]=rng.choice(vals)
        elif typ=="int":
            g[name]=int(_clamp(int(g.get(name,d.get("default",d["min"])))+rng.choice([-1,1]),d["min"],d["max"]))
        elif d.get("mutation")=="log" and d["min"]>0:
            g[name]=_clamp(float(g.get(name,d.get("default",d["min"]))) * math.exp(rng.gauss(0,d.get("sigma",.15)*strength)),d["min"],d["max"])
        else:
            g[name]=_clamp(float(g.get(name,d.get("default",0)))+rng.gauss(0,d.get("sigma",(d["max"]-d["min"])*.08)*strength),d["min"],d["max"])
    if not touched and surface:
        name=rng.choice(list(surface)); d=surface[name]; g[name]=_sample_one(d,rng)
    return g
