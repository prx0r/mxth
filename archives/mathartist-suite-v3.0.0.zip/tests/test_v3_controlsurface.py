import random,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from controlsurface.engine import random_controls, mutate_controls, validate_control_surface

SPEC={"control_surface":{
 "h":{"type":"float","min":.001,"max":.05,"default":.006,"sigma":.002,"role":"family","claim_scope":"same-family","provenance":"paper eq X"},
 "branch":{"type":"enum","values":["a","b"],"default":"a","role":"branch","claim_scope":"same-family","provenance":"construction cases"},
 "n":{"type":"int","min":1,"max":8,"default":3,"role":"sampling","claim_scope":"observation-only","provenance":"sampling contract"}
}}
def test_surface_valid(): assert validate_control_surface(SPEC)==[]
def test_random_and_mutation_stay_in_surface():
 r=random.Random(7); g=random_controls(SPEC,r)
 for _ in range(100): g=mutate_controls(SPEC,g,r)
 assert .001<=g['h']<=.05 and g['branch'] in ['a','b'] and 1<=g['n']<=8

def test_provenance_required():
 bad={"control_surface":{"x":{"type":"float","min":0,"max":1,"role":"family","claim_scope":"same-family"}}}
 assert any('provenance' in x for x in validate_control_surface(bad))
