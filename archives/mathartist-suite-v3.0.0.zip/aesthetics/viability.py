from __future__ import annotations
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
DEFAULT=json.loads((ROOT/'aesthetics/specimen_grammar.v1.json').read_text())

def gate(m, grammar=DEFAULT):
    c=grammar['composition'];reasons=[]
    def rng(k):
        lo,hi=c[k];v=float(m.get(k,0));
        if v<lo:reasons.append(k+':low')
        elif v>hi:reasons.append(k+':high')
    for k in ('foreground_occupancy','bbox_area_ratio','mean_luminance','edge_density'):
        metric={'foreground_occupancy':'occupancy','mean_luminance':'mean'}.get(k,k)
        lo,hi=c[k];v=float(m.get(metric,0))
        if v<lo:reasons.append(metric+':low')
        elif v>hi:reasons.append(metric+':high')
    if float(m.get('centroid_offset',1))>c['centroid_offset_max']:reasons.append('off-center')
    if float(m.get('contrast',0))<c['contrast_min']:reasons.append('low-contrast')
    if float(m.get('saturation_fraction',1))>c['saturation_fraction_max']:reasons.append('overexposed')
    return {'pass':not reasons,'reasons':reasons}
