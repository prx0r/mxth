export function R(seed){let s=seed>>>0;return()=>((s=Math.imul(s,1664525)+1013904223>>>0)/4294967296)}
const genes=["view","phase","exposure","persist","zoom","twist"];
export function population(model,seed,gen,count,parents=[]){let r=R(seed+gen*7919),base=parents.length?parents:[model.base];return Array.from({length:count},(_,i)=>{
 let p=base[Math.floor(r()*base.length)],g={...p}; for(let k of genes){let d=(r()+r()+r()-1.5);g[k]=(g[k]??0)+d*(k==="view"?1.7:k==="zoom"?.22:k==="exposure"?.18:.5)}
 g.view=Math.round(Math.abs(g.view))%6;g.exposure=Math.max(.15,Math.min(1,g.exposure));g.zoom=Math.max(.55,Math.min(1.8,g.zoom));g.persist=Math.max(0,Math.min(.8,g.persist));g.twist=Math.max(.2,Math.min(3,g.twist));
 return {g,id:`${String(gen).padStart(3,"0")}.${String(i).padStart(2,"0")}`,parent:parents.length?"selected":"wander"} })}