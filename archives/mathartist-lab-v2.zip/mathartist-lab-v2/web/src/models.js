const TAU=Math.PI*2;
export const models={
NS26:{label:"NS26 / singular flow",kind:"FRONTIER",base:{view:0,phase:.2,exposure:.7,persist:.3,zoom:1,twist:1},
sample(i,n,g,t){
 const u=i/n, eta=2*((i*.61803398875)%1)-1, tau=.035+.22*(.5+.5*Math.sin(t*.08+g.phase));
 const h=.006, rs=Math.pow(tau,.5), zs=Math.pow(tau,.5-h), vel=Math.pow(tau,-.5-h);
 const X=.03+4*((i*.754877666)%1), r=Math.sqrt(2*tau*X)*rs*6;
 const pulse=Math.sin(eta*9+X*7-t*vel*.03);
 const a=TAU*u*29+g.twist*vel*.02*t+.55*pulse;
 return [r*Math.cos(a),zs*eta*7+.15*pulse,r*Math.sin(a),.25+.75*Math.abs(pulse)]
}},
BIOELECTRIC:{label:"BIO / voltage collective",kind:"BIOLOGY",base:{view:0,phase:.5,exposure:.65,persist:.25,zoom:1,twist:1},
sample(i,n,g,t){
 // Minimal synthetic coupled-field demonstrator. Not experimental Levin data.
 const u=(i%181)/180, v=Math.floor(i/181)/(Math.ceil(n/181));
 const x=(u-.5)*5.5,y=(v-.5)*5.5;
 const f1=Math.sin(1.5*x+.35*t+g.phase)+Math.cos(1.25*y-.21*t);
 const f2=Math.sin(Math.hypot(x+1.15,y-.55)*3.1-.3*t);
 const V=Math.tanh(.75*f1+.55*f2);
 const gate=1/(1+Math.exp(-5*(V-.12*Math.sin(t*.17))));
 const z=(gate-.5)*1.8+.22*Math.sin(3*x-2*y+t*.15);
 return [x,y,z,.18+.82*Math.abs(V)]
}},
LENIA:{label:"ALIFE / continuous field",kind:"BIOLOGY",base:{view:0,phase:.1,exposure:.72,persist:.2,zoom:1,twist:1},
sample(i,n,g,t){
 const a=TAU*((i*.61803398875)%1), rr=1.1+1.4*((i*.41421356237)%1);
 const lob=5+2*Math.sin(t*.07+g.phase), r=rr*(1+.28*Math.sin(lob*a+t*.22)+.13*Math.sin(3*a-t*.31));
 const x=r*Math.cos(a),y=r*Math.sin(a),z=.5*Math.sin(2*a+t*.17)+.3*Math.cos(r*3-t*.13);
 return [x,y,z,.25+.75*Math.abs(Math.sin(lob*a+t*.22))]
}}
};
