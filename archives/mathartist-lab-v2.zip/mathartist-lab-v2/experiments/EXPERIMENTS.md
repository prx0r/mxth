# Experiments

## E0 — visual identity
Blindly mix 100 specimens/source. Test whether source families remain distinguishable under a
shared monochrome interpretation grammar. If not, interpretation operators are overpowering source math.

## E1 — open evolution
Archive novelty without preference. Preserve lineage and stepping stones. Sakana-style archive sampling:
random + recent + highly rated + highly branched, with a small random-selection probability.

## E2 — personal For You
Favorites, dwell, fullscreen, replay and revisit train preference over interpretation descriptors.
Never alter the immutable source. Keep an exploration quota.

## E3 — attention horizons
Randomly assign fixed videos from the same source family. Separate objectives:
5s stop, 10s conditional survival, 20s conditional survival, replay. Do not call these "rasa".

## E4 — structural hypotheses
Pre-register tests relating approximate symmetry, symmetry gradient, recurrence, entropy, spectral
concentration and compression proxies to attention/liking/return. QRI-inspired claims are hypotheses,
not established neuroscience.

## E5 — biology
Use BETSE or a paper-specific executable model. Freeze the biological dynamics. Evolve only views of
voltage distributions, currents, state-space trajectories and multiscale summaries. Compare whether
biological source fields occupy different aesthetic niches than frontier-math sources.
