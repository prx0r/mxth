# MathArtist Lab V2 — immutable science, evolving interpretations

A runnable research prototype for evolving **ways of seeing** immutable mathematical / biological models.

## Run the gallery
```bash
cd web
python3 -m http.server 8080
# open http://localhost:8080
```

No build step and no JS dependencies.

## Core contract
`source state -> interpretation genome -> monochrome phenotype`

The source model is never mutated by the evolutionary layer. Interpretation genes control sampling,
projection, temporal phase, camera, persistence, exposure, point size, and a small set of declared
source-safe observation transforms.

Included source artists:
- `NS26`: proof-derived Navier–Stokes similarity-field demonstrator.
- `BIOELECTRIC`: a deliberately minimal multicellular voltage-field demonstrator inspired by
  developmental-bioelectric patterning; it is **not** a reproduction of a Levin-lab experiment.
- `LENIA`: a compact continuous-life demonstrator / bridge target for the upstream Lenia project.

## UI
The gallery intentionally copies the *interaction philosophy*, not assets/code, of the supplied
black specimen-grid reference: almost all screen area is living monochrome organisms.
Tabs: FRONTIER / OPEN / 5s / 10s / 20s / REPLAY / FOR YOU / FAVORITES.

Click = select parent. Star = favorite. Evolve = descendants. All state is stored locally.

## External integrations (not vendored)
See `adapters/README.md`.
- Paper2Agent: paper -> executable paper-agent/MCP.
- Sakana AI Picbreeder-VLM: archive/phylogeny/open-ended-agent design reference.
- pyribs: quality-diversity / MAP-Elites backend.
- BETSE: real bioelectric tissue simulator.
- Lenia / Leniabreeder: artificial-life phenotype and QD source.
- YouTube Analytics: future external attention fitness.

We do not copy third-party code into this ZIP. Adapters keep provenance and licensing explicit.
