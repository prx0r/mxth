# Integration plan — reuse, don't recreate

This ZIP intentionally does not vendor third-party repositories.

## Paper2Agent
Upstream: https://github.com/jmiao24/Paper2Agent
Role: paper + code + supplements -> executable MCP/paper-agent.
Adapter contract: emit a manifest of executable observables and provenance. MathArtist then freezes
the selected source implementation and evolves only observation/interpretation parameters.

## Sakana AI Picbreeder-VLM
Upstream project: https://pub.sakana.ai/picbreeder-vlm/
Role reused conceptually: unbounded shared archive, phylogeny, branching, agent selection, critic,
random/recency/rating/branch-popularity sampling, and deliberate noise to escape attractors.
We DO NOT use CPPNs as the scientific genotype; our genotype is the interpretation genome.

## pyribs
Upstream: https://github.com/icaros-usc/pyribs
Role: replace the tiny browser mutator with GridArchive/CVTArchive + emitters when running research
experiments. Browser mode remains useful for interactive human breeding.

## BETSE
Upstream: https://github.com/betsee/betse
Role: executable developmental-bioelectric tissue fields (ion channels, gap junctions, voltages,
currents, GRNs). Export state snapshots; MathArtist treats those snapshots/dynamics as immutable.

## Lenia / Leniabreeder
Upstreams:
- https://github.com/Chakazul/Lenia
- https://github.com/maxencefaldor/Leniabreeder
Role: living mathematical morphology and an existing open-ended/QD research bridge.

## YouTube
Future adapter: upload rendered fixed-duration organisms and import per-video retention / replay /
engagement metrics. Keep a controlled first-party random-assignment experiment separate from the
YouTube observational environment.
