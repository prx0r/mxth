# Architecture

PAPER / MODEL
  -> Paper2Agent (when appropriate)
  -> executable source + provenance
  -> IMMUTABLE SOURCE ADAPTER
  -> interpretation genome
  -> monochrome renderer
  -> archive + lineage
       | open novelty/QD
       | human For You
       | external attention experiments

The one hard rule:
**no evolutionary operator may modify the source equations, ratios, update law, data, or fitted
parameters that define the selected scientific artifact.**

Interpretation genes may only change how valid source observables are sampled, sliced, projected,
sequenced in time, shaded, persisted, or viewed.
