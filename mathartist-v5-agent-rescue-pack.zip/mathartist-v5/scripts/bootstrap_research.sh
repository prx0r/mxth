#!/usr/bin/env bash
set -euo pipefail
ROOT="${1:-research/upstreams}"
PAPERS="${2:-research/papers}"
mkdir -p "$ROOT" "$PAPERS"

clone_repo(){ local url="$1" name="$2"; if [ -d "$ROOT/$name/.git" ]; then git -C "$ROOT/$name" fetch --all --tags --prune; else git clone --filter=blob:none "$url" "$ROOT/$name"; fi; }

clone_repo https://github.com/smearle/picbreeder-vlm.git picbreeder-vlm
clone_repo https://github.com/processing/p5.js.git p5.js
clone_repo https://github.com/microsoft/playwright.git playwright
clone_repo https://github.com/acornjs/acorn.git acorn
clone_repo https://github.com/Rich-Harris/magic-string.git magic-string
clone_repo https://github.com/icaros-usc/pyribs.git pyribs
clone_repo https://github.com/adaptive-intelligent-robotics/QDax.git qdax
clone_repo https://github.com/SakanaAI/asal.git asal
clone_repo https://github.com/SakanaAI/ShinkaEvolve.git shinkaevolve
clone_repo https://github.com/SakanaAI/digital-ecosystem.git digital-ecosystem
clone_repo https://github.com/jmiao24/Paper2Agent.git paper2agent
clone_repo https://github.com/jmiao24/Paper2AgentBench.git paper2agentbench
clone_repo https://github.com/facebookresearch/dinov2.git dinov2
clone_repo https://github.com/google-research/big_vision.git big_vision

: > "$ROOT/LOCKED_HEADS.tsv"
for d in "$ROOT"/*; do
  [ -d "$d/.git" ] || continue
  printf "%s\t%s\t%s\n" "$(basename "$d")" "$(git -C "$d" rev-parse HEAD)" "$(git -C "$d" remote get-url origin)" >> "$ROOT/LOCKED_HEADS.tsv"
done

download(){ local url="$1" out="$2"; [ -f "$PAPERS/$out" ] && return; curl -L --fail --retry 3 "$url" -o "$PAPERS/$out"; }
download https://arxiv.org/pdf/2605.23908 picbreeder-vlm-2026.pdf
download https://arxiv.org/pdf/2509.06917 paper2agent-2026.pdf
download https://arxiv.org/pdf/1504.04909 map-elites-2015.pdf
download https://arxiv.org/pdf/2412.17799 asal-2024.pdf
download https://arxiv.org/pdf/2509.19349 shinkaevolve-2026.pdf
download https://pub.sakana.ai/digital-ecosystem/paper/paper.pdf digital-ecosystems-2026.pdf
download https://www.campbellssite.com/papers/secretan_chi08.pdf picbreeder-chi-2008.pdf
sha256sum "$PAPERS"/*.pdf > "$PAPERS/SHA256SUMS"
echo "Research cache ready. DO NOT vendor it into release artifacts."
