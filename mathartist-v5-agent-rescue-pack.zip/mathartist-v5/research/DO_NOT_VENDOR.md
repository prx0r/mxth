# Research cache policy

`research/upstreams/` and downloaded papers are local troubleshooting/research caches.

Do not automatically put them in MathArtist releases.

Before copying third-party code:
- inspect license
- pin commit
- record provenance
- prefer adapter/import over vendoring
- exclude unknown-license corpus code from distributable ZIPs
