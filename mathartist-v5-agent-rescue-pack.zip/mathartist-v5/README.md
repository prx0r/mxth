# MathArtist V5 Agent Rescue Pack

Start with `00_READ_ME_FIRST.md`, then hand the coding agent `docs/14_AGENT_COMMAND.md`.

This pack is a corrective implementation guide for `prx0r/mxth` at the reviewed HEAD. It includes:
- anti-drift instructions;
- direct answers to current blockers;
- real AST classifier reference;
- persistent Playwright batch renderer;
- intervention-probe reference;
- actual Sobol batch orchestration;
- B25_FERTILE selection tool;
- result validator/schema;
- research clone/download bootstrap.

Third-party repositories and papers are intentionally not bundled. Use `scripts/bootstrap_research.sh`.
