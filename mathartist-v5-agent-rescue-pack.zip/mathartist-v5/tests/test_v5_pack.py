from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
def test_plan():
    p=json.loads((ROOT/"machine/V5_PLAN.json").read_text())
    assert "25 real fertile seeds" in p["objective"]
    assert "runtime switching" in p["do_not_do"]
def test_schema():
    s=json.loads((ROOT/"schemas/descendant.schema.json").read_text())
    assert "valid" in s["properties"]["technical_status"]["enum"]
    assert "timeout" in s["properties"]["technical_status"]["enum"]
def test_research():
    r=json.loads((ROOT/"research/repos.json").read_text())
    names={x["repo"] for x in r}
    assert "smearle/picbreeder-vlm" in names
    assert "jmiao24/Paper2AgentBench" in names
    assert "acornjs/acorn" in names
def test_key_tools_exist():
    for x in ["classify_literals_ast.mjs","render_batch.cjs","probe_controls.py","run_b25_v5.py","select_b25_fertile.py"]:
        assert (ROOT/"tools"/x).exists()
