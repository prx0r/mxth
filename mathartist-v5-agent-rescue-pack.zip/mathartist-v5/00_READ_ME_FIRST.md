# MathArtist V5 — agent rescue / finish-the-experiment pack

Target repository: `prx0r/mxth`
Reviewed HEAD: `248034f06390561108bd0274c21d876ccf289d3d`

## Mission

Stop platform drift and finish the real emergence experiment.

The next job is not another architecture, source family, dashboard tab, classifier framework, or VLM judge.

The next job is:

1. get 25 genuinely mutable real #つぶやきProcessing seeds to reproduce;
2. define an honest ART_PROGRAM mutation regime;
3. batch-render 25,000 descendants without relaunching Chromium per specimen;
4. persist thumbnails/images + full genotype/runtime metadata;
5. build morphology coverage atlases;
6. connect the results to the human POTENTIAL → BRANCH loop;
7. only then return to frontier-paper integration.

## Critical findings from latest code

- `classify_literals.py` says “AST-based” but is regex-context classification.
- `build_b25.py` has an unverified hard-coded reference list and silently fills missing rows.
- `run_b25.py` launches a Node process and Chromium for every descendant.
- its function named `sobol_sample()` is not a real Sobol implementation.
- it seeds using Python `hash(seed_id)`, which is not stable across processes unless configured.
- mutation ranges can invert for negative literals.
- the renderer hashes a full-page screenshot instead of the canvas.
- Python reads `execution_time_ms` while current Node emits `execution_ms`.
- 25k render hashes without image/embedding artifacts are not enough for morphology.
- current harness injects sketch code before p5.js, unlike normal p5 loading order.

These are fixable. Do not replatform.
