# Exact coding-agent command

Continue `prx0r/mxth` from the commit containing `docs/BLOCKERS.md`.

Read the entire V5 pack before changing code.

## Mission

Finish the real 25k emergence experiment and connect it to human branching.

## Rules

- Chromium/Playwright is final. Do not switch runtimes.
- Use ART_PROGRAM provenance for #つぶやきProcessing.
- Use SCIENCE_STRICT only for scientific sources.
- Replace regex classification with Acorn AST.
- Do not fabricate curated seed IDs/descriptions.
- Do not call a home-made sequence “Sobol”.
- Do not launch a browser per descendant.
- Do not produce a hashes-only dataset.
- Do not add platform features before benchmark completion.

## Immediate order

1. patch package dependencies for Acorn + MagicString;
2. replace current classifier with the supplied AST version;
3. add persistent Chromium batch renderer;
4. fix p5 script order and canvas-only capture;
5. replace Python `hash(seed_id)` with SHA256-derived deterministic seeds;
6. use `scipy.stats.qmc.Sobol` or another genuine tested Sobol;
7. fix negative/zero mutation ranges;
8. persist thumbnails/images + JSONL;
9. run 3 seeds × 100 and visually inspect;
10. build B25_FERTILE;
11. run 25 × 100 smoke;
12. run 25 × 1,000;
13. build coverage atlas;
14. wire output to POTENTIAL→BRANCH;
15. write `V5_RESULTS.md`.

Do not stop to ask ordinary implementation questions. Choose the simplest path consistent with this pack and keep running.
