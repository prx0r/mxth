# Research library to clone for future defense/troubleshooting

Clone into `research/upstreams/`. Do not silently vendor these into releases.

## Highest priority

- `smearle/picbreeder-vlm` — 2026 Picbreeder reconstruction, archive/phylogeny, breeding UI, evaluations, parallelism.
- `processing/p5.js` — runtime semantics and compatibility ground truth.
- `microsoft/playwright` — Clock, page/context lifecycle, screenshot behavior.
- `acornjs/acorn` — AST parser, loose parser, walker.
- `Rich-Harris/magic-string` — source-preserving edits.

## Open-ended search / QD

- `icaros-usc/pyribs`
- `adaptive-intelligent-robotics/QDax`
- `SakanaAI/asal`
- `SakanaAI/ShinkaEvolve`

## Interactive emergence

- `SakanaAI/digital-ecosystem` — checkpoint → branch → explore UX.

## Scientific paper ingestion / troubleshooting

- `jmiao24/Paper2Agent`
- `jmiao24/Paper2AgentBench` — adversarial broken repos, missing deps, broken paths, deprecated APIs.

## Morphology representation

- `facebookresearch/dinov2`
- `google-research/big_vision`

Use visual encoders as frozen morphology representations, never beauty judges.
