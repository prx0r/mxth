# Reproducibility protocol

## p5 script order

Load p5 before the sketch.

A sketch may call p5 APIs at top level; current reverse order can break that.

## Fidelity

Exact/default means:
- exact source bytes
- pinned p5
- browser version recorded
- source-native execution
- canvas capture
- no mutation
- instrumentation does not change semantics beyond observation

## Stochastic defaults

If original uses unseeded `random()` / `noise()`:
- render hashes may differ legitimately;
- run 3 repeats;
- mark stochastic=true;
- record technical validity and morphology consistency.

## Search reproducibility

SEARCH mode may inject recorded `randomSeed()` and `noiseSeed()` and virtual time.

Each descendant must record:
- source SHA
- parameterization version
- theta
- mutation seed
- p5/browser versions
- frame
- random/noise seeds
- renderer mode
- render SHA
