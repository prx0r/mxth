# Troubleshooting decision tree

## Seed is black

1. run original in FIDELITY;
2. inspect page errors;
3. confirm canvas exists;
4. confirm p5 loaded before sketch;
5. verify frame/time;
6. compare real-time vs virtual-time;
7. inspect stochastic init;
8. only then inspect mutation.

Do not switch runtimes.

## Candidate count zero

1. verify AST parse;
2. inspect numeric nodes;
3. confirm ART_PROGRAM regime;
4. intervention-probe UNKNOWN arithmetic numerics;
5. if still zero, mark low-dimensional and move on.

## Descendants identical

1. verify source rewrite;
2. log transformed-source hash;
3. perturb one control at a time;
4. compare images/hashes;
5. widen effectful range carefully.

## Descendants crash

1. default must still pass;
2. distinguish harness crash from mutation crash;
3. shrink range;
4. retain crash fraction as brittleness evidence.

## Run slow

1. verify one Chromium launch;
2. verify no per-specimen Node subprocess;
3. add page concurrency gradually;
4. virtual clock in SEARCH;
5. profile heavy seeds separately.

## Run changes across repeats

Check:
- Python hash usage
- RNG/noise seeds
- browser version
- frame
- git SHA
- stochastic default
- clock instrumentation

Use SHA256-derived integer seeds, not Python `hash()`.
