# Latest push review

The agent's new `BLOCKERS.md` is useful because it finally identifies the actual problem: drift.

## Keep

- Playwright / real Chromium
- pinned p5 runtime
- lineage channels
- strict SCIENCE control surfaces
- B25 manifest idea
- the 994-record real corpus
- POTENTIAL / BRANCH separation
- provenance labels

## Correct

### Regex is not AST

The current literal tool searches ±40-character windows. That directly explains why `t=0` can be misclassified by unrelated nearby `createCanvas` text.

Replace it with:
- `acorn`
- `acorn-loose`
- `acorn-walk`
- `magic-string`

### Separate two provenance regimes

For scientific papers: only evidence-backed upstream controls may mutate.

For tiny generative-art programs: define an honest **derived local program family** by mutating generative AST literals while preserving topology. Do not pretend the artist declared these parameters.

### The current “reference” benchmark is not a real curated benchmark

Stop using it for acceptance. Build `B25_FERTILE` from measured eligibility, not invented semantic notes.

### Throughput is architectural, not a reason to abandon Playwright

Keep one browser alive. Render jobs through fresh pages or a small worker-page pool.

### Hashes alone are not useful enough

Store thumbnails/images or morphology embeddings for valid descendants.
