# AST + intervention mutation pipeline

## 1. Parse

Use:
- `acorn`
- `acorn-loose`
- `acorn-walk`
- `magic-string`

## 2. Hard classify

Exclude:
- createCanvas/resizeCanvas
- color functions
- frame/pixel density
- literal loop/sample budgets
- obvious array indices

Candidate:
- arithmetic feeding point/vertex/transforms/state
- trig/noise/random arguments and surrounding coefficients
- exponent RHS
- assignment initialization
- time increments
- conditional thresholds

UNKNOWN remains eligible for probing, not automatic admission.

## 3. Intervention probe

For each candidate with default v, render:
- v - δ
- v
- v + δ

Record:
- valid/crash/blank
- morphology/pixel change
- runtime

Classify:
- NO_EFFECT
- DISPLAY_ONLY
- EFFECTFUL
- BRITTLE
- EXPENSIVE

## 4. Admit compact surface

Use 3–10 effectful controls initially.

## 5. Ranges

Never blindly use `[v*0.1, v*10]`.

Use:
- positive scale/frequency: roughly `[v/3, 3v]`
- negative multiplicative value: preserve sign and sort endpoints
- zero: additive interval from probe
- phase: `v ± π` or `2π`
- exponent: conservative local interval
- integer selector: discrete neighbors
- time step: positive log-local interval unless reverse time is meaningful
