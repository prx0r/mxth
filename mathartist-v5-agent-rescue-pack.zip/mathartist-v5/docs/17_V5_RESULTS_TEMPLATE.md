# V5_RESULTS

## Repository
commit:

## Runtime
p5:
Playwright:
Chromium:
classifier:
sampler:

## B25_FERTILE
manifest SHA:
artists:
mechanism classes:

## Default fidelity
passed:
stochastic:
failed:

## Mutation controls
median:
range:
examples:

## Full run
attempted:
valid:
crash:
blank:
timeout:
wall time:
specimens/sec:

## Morphology
representation:
coverage:
notable basins:

## Human branch test
parent:
branch scale:
offspring:
depth:

## What actually worked

## What failed

## What we learned about fertile program structure

## What remains unproven

## Next bottleneck
One sentence.
