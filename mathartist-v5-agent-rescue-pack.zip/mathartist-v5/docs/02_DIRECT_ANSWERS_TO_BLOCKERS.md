# Direct answers to the five blockers

## 1. Literal classifier

Do not mutate every number blindly. Do not keep the regex classifier.

Use:

1. AST extraction.
2. Hard exclusions for runtime/display/sampling constants.
3. Small intervention tests (`v-δ`, `v`, `v+δ`).
4. Admit 3–10 effectful controls per seed.

This is simpler and more reliable than trying to statically infer full semantics.

## 2. 25k speed

Fourteen hours is acceptable if the work is real, but the current estimate is mostly repeated browser-launch overhead.

Fix first:
- one Chromium process;
- 2–8 concurrent fresh pages;
- deterministic virtual time for SEARCH;
- fidelity rendering separately.

If it still takes hours, run it.

## 3. Simple B25 seeds

Keep low-dimensional sketches in `B25_UNBIASED` because that is real corpus evidence.

Do not force them into the 25k art benchmark.

Create `B25_FERTILE`, where eligibility is:
- default runs;
- nonblank;
- >=3 effectful ART_PROGRAM controls;
- no unsupported assets/input;
- bounded render cost.

That is eligibility, not aesthetic cherry-picking.

## 4. Complex sketch fidelity

Use two modes.

FIDELITY:
- source-native real-browser execution;
- no injected RNG unless original does it;
- repeat stochastic defaults rather than demanding identical hashes.

SEARCH:
- same Chromium/p5 runtime;
- deterministic recorded random/noise seeds;
- fixed frame/time;
- explicit instrumentation metadata.

## 5. Success

Success means:
- 25 real B25_FERTILE seeds;
- all defaults execute;
- >=3 admitted effectful controls each;
- 25,000 attempted descendants persisted;
- every attempt gets a status;
- valid descendants retain image/thumbnail or embedding;
- random and coverage atlases exist;
- OPEN_BLIND gets no human signal;
- dashboard branching produces a new visible generation.

There is no universal acceptable descendant failure rate. Mutation-induced failure is useful brittleness data.
