# Two provenance regimes

## ART_PROGRAM

Applies to #つぶやきProcessing and generative-art code.

Object:

`original P → topology frozen → selected numeric AST literals become θ → derived family P(θ)`

Allowed:
- generative coefficients
- frequencies/phases
- exponents
- time steps
- initial state
- branch thresholds

Initial exclusions:
- canvas dimensions
- colors
- sample budgets
- obvious display offsets
- external assets

Claim only:
> This is a derived parameterization of the original program.

Do not claim the artist explicitly exposed the parameters.

## SCIENCE_STRICT

Applies to papers/simulations.

Only mutate if:
- upstream admits the control;
- domain is evidenced;
- invariants are preserved;
- reference reproduction passes.

No automatic literal mutation.

## Why

The current agent applied SCIENCE_STRICT to tiny art programs. That made many seeds falsely look zero-dimensional.
