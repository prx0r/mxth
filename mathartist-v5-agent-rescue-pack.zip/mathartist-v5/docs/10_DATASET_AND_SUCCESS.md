# Dataset schema and success criteria

## One row per attempted descendant

Required:
- specimen_id
- run_id
- seed_id
- source_code_sha256
- parameterization_sha256
- theta
- parent_ids
- lineage_channel
- sampler + sampler_index
- rng_seed / noise_seed
- capture_frame
- renderer_mode
- technical_status
- render_sha256
- image_path or morphology_vector for valid output
- execution_ms
- mutation_metadata

## Run manifest

Record:
- git SHA
- B25 manifest SHA
- p5 SHA/version
- Playwright/browser version
- classifier version
- sampler version
- morphology version
- start/end times
- attempted/valid counts

## Success is not 100% valid descendants

Per seed report:
- attempted
- valid
- blank
- crash
- timeout
- distinct render hashes
- coverage
- median runtime
- admitted controls

Hard gates:
- 25 defaults pass
- 25 have >=3 effectful controls
- 25,000 attempts persisted
- valid outputs have image/embedding data
- run is resumable
- OPEN_BLIND has no human input
- coverage atlas exists
- branch workflow works
