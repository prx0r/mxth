# Web research findings resolving current uncertainty

## Playwright

The official Clock API controls `requestAnimationFrame`, timers, `performance`, and event timestamps. That supports a deterministic real-browser SEARCH mode.

## p5

Official docs confirm:
- `randomSeed()` makes `random()` / `randomGaussian()` reproducible.
- `noiseSeed()` makes `noise()` reproducible.
- `frameCount` increments after each completed `draw()`.

Keep the corpus benchmark pinned; do not upgrade p5 simply because a newer release exists.

## Picbreeder-VLM

The public repo exposes:
- breeding/archive loop
- lineages
- resume/test/mock modes
- visual coverage/tree evaluation
- expensive model daemon reused by many jobs

That last operational pattern directly motivates keeping Chromium alive across specimen jobs.

## Paper2AgentBench

Clone it now as future scientific-source defense/troubleshooting material because it intentionally includes broken repository variants.

## Quality diversity

Use QD ideas after the first benchmark proves a need; do not port a full framework before the 25k run.
