# Anti-drift constitution

## Current objective

**Produce and inspect the first real 25,000-specimen MathArtist art-emergence dataset and connect it to human branching.**

## Allowed work before completion

Only work that directly removes:
1. exact seed execution
2. mutation candidate extraction
3. seed eligibility
4. render throughput
5. specimen persistence
6. morphology compression
7. human branching

## Forbidden until the benchmark completes

- new scientific source families
- NS26 embellishment
- new QRI/rasa metrics
- YouTube work
- new dashboard tabs
- backend rewrites
- DSLs/plugin frameworks
- VLM beauty scoring
- switching away from Chromium
- “cleanup” work that does not unblock the benchmark

## Stop question

Before starting a task ask:

> Will this make the 25 real seeds execute, mutate, render, compress, or branch?

If no: put it in AFTER_V5 and continue.

## Progress log

After each work block append:

- what changed
- benchmark blocker removed
- evidence
- specimens successfully produced
- next single action
