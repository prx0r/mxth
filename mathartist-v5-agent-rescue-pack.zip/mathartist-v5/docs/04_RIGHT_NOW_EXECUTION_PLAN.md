# Right-now execution plan

Do this in order.

## Phase 0 — one hour maximum

1. add Acorn / Acorn-loose / Acorn-walk / MagicString;
2. replace regex literal classification;
3. patch renderer to load p5 before sketch, capture canvas-only, and support persistent batch mode;
4. fix deterministic seed derivation and mutation ranges.

Then stop tooling.

## Phase 1 — three-seed proof

Pick three known structurally rich real corpus seeds.

For each:
- default fidelity render;
- AST candidates;
- intervention screen;
- admit 3–8 effectful controls;
- render 100 descendants;
- save thumbnails;
- create random and coverage contact sheets.

Human-inspect the sheets.

Proceed only if descendants visibly vary while preserving recognizable structure.

## Phase 2 — B25_FERTILE

Probe corpus rows until 25 eligibility-passing seeds exist.

Selection must be deterministic after eligibility and stratified across creator/mechanism/code hash.

No invented IDs. No synthetic semantic descriptions.

## Phase 3 — 25 × 100 smoke

Render 2,500 descendants before 25k.
Check:
- failure classes;
- artifacts;
- morphology;
- throughput.

## Phase 4 — 25 × 1,000

Resume-capable and append-only.
Never restart because one specimen fails.

## Phase 5 — gallery + branch

Load coverage representatives into the human breeding dashboard:
POTENTIAL → mutation pressure → BRANCH → preserved ancestry.

## Phase 6 — results

Write `V5_RESULTS.md`.

Then return to paper adapters.
