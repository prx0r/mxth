# Renderer throughput

The current bottleneck is:

Python → Node → Chromium launch **per specimen**

Do not do that.

## Correct architecture

Python sampler
→ JSONL job manifest
→ one Node batch renderer
→ one Chromium browser
→ N concurrent fresh pages
→ canvas image + result JSONL

Fresh pages provide isolation without browser startup cost.

## Borrow from Picbreeder-VLM

That repo keeps an expensive model daemon alive while many experiment jobs reuse it.

Use the same idea:

> Chromium is the daemon. Specimen renders are jobs.

## Modes

FIDELITY:
- real clock
- no injected RNG
- source-native
- only for default validation

SEARCH:
- Playwright Clock
- recorded randomSeed/noiseSeed
- fixed capture frame
- reproducible/high-throughput

## Concurrency

Start:
- 2 workers on 2-core
- 4 workers on 4+ core

Increase only if measured throughput improves.

## Artifacts

For valid descendants store:
- 256–400 px JPEG thumbnail
- render SHA
- morphology features/embedding

Do not commit 25k images to git.
