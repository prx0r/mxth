# Source notes

The V5 fixes are grounded in:

- official Playwright Clock documentation: clock installation controls requestAnimationFrame, timers, performance, and related time APIs;
- official p5 references: `randomSeed()` and `noiseSeed()` make their respective randomness reproducible; `frameCount` increments per completed draw;
- `smearle/picbreeder-vlm`: persistent expensive-model serving, archive phylogeny, breeding/resume/test/evaluation patterns;
- current `prx0r/mxth` source at reviewed HEAD, especially `BLOCKERS.md`, `classify_literals.py`, `reproduce_seed.cjs`, `run_b25.py`, and `build_b25.py`.

Do not treat links or cloned repositories as permission to redistribute them. Inspect licenses and keep research caches outside release artifacts.
