# Patch list by current repo file

## package.json
Add:
- acorn
- acorn-loose
- acorn-walk
- magic-string

Keep Playwright pinned by lockfile.

## tools/classify_literals.py
Replace regex semantics with a thin wrapper around the canonical Node AST classifier, or delete the Python copy.

Do not keep two independent classifiers.

## tools/reproduce_seed.cjs
Use for FIDELITY:
- p5 before sketch
- canvas screenshot
- stochastic repeat support

Do not use as 25k per-sample entrypoint.

## new tools/render_batch.cjs
One browser for the entire job batch.

## tools/run_b25.py
Rewrite as orchestration:
- genuine Sobol
- SHA-derived seed
- build jobs
- invoke batch renderer once
- merge results
- persist images
- resume

## tools/build_b25.py
Delete unverified REFERENCE_SEEDS.
Keep unbiased selection.
Add B25_FERTILE from probe results.

## seeds/B25_REFERENCE.json
Archive/rename as `B25_REFERENCE_V4_UNVERIFIED.json`.

## output
Add `runs/` and `research/upstreams/` to gitignore.
Version only manifests, summaries and selected/contact-sheet outputs.
