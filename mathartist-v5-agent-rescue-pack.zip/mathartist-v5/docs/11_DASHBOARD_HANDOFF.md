# Human aesthetic dashboard handoff

Do not rebuild the dashboard during the benchmark.

Creative surface:
- OPEN
- POTENTIAL
- LINEAGE
- SAVED
- STUDY

Creative loop:
1. machine shows 12–24 coverage-diverse specimens;
2. human clicks POTENTIAL;
3. chooses MICRO / SMALL / MEDIUM / WILD;
4. BRANCH;
5. selected parent survives unchanged;
6. descendants preserve exact parameter deltas and ancestry.

Branch is the strongest taste signal.

Never feed POTENTIAL/branch/favorite/dwell into OPEN_BLIND.

Later FOR_YOU may learn:
`P(branch | morphology, source, lineage)`
while reserving diversity/OOD slots.

This mirrors Picbreeder-style interactive breeding and Sakana's checkpoint → branch → explore interaction.
