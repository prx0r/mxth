# V5 acceptance gates

## G0 anti-drift
- no new source/platform feature

## G1 renderer
- one Chromium launch per batch
- p5 before sketch
- canvas-only screenshot
- fidelity + search modes
- deterministic search RNG/time
- resume

## G2 mutation
- real AST parser
- source spans
- intervention probe
- ART_PROGRAM vs SCIENCE_STRICT
- 3–10 effectful controls/eligible seed

## G3 seeds
- no invented reference IDs/notes
- B25_UNBIASED retained
- B25_FERTILE has 25 real passing seeds
- repo-relative paths

## G4 sampling
- real Sobol
- SHA-derived deterministic seed
- local/global/boundary sampler labels
- sane negative/zero ranges

## G5 data
- 25,000 attempted records
- valid specimen image/thumbnail or embedding
- render SHA
- theta/runtime provenance
- failure classes retained

## G6 art evidence
- per-seed random contact sheet
- per-seed coverage contact sheet
- aggregate atlas
- fertility/brittleness report

## G7 human loop
- POTENTIAL selection
- mutation pressure
- parent survives
- ancestry stored
- visible new generation

## G8 release
- clean run command
- SHA manifest
- research cache excluded
- unknown-license corpus code excluded from release
- V5_RESULTS.md
