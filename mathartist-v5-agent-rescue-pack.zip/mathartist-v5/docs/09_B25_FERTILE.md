# Replace fake “reference” benchmark with B25_FERTILE

## Current problem

`build_b25.py` contains a manual `REFERENCE_SEEDS` list with semantic descriptions that the selection code does not verify. Missing IDs are silently replaced by hash-sorted corpus rows.

Do not use this as V5 acceptance evidence.

## Keep two datasets

### B25_UNBIASED

Purpose: measure the real corpus distribution, including simple or zero-dimensional sketches.

Do not force every member to have 1,000 descendants.

### B25_FERTILE

Purpose: run the 25k local-evolvability/art experiment.

Eligibility:
- real corpus row
- local code available
- attribution/hash recorded
- default fidelity succeeds
- output nonblank
- >=3 effectful ART_PROGRAM controls
- no unsupported external input/assets
- bounded render cost

Then stratify deterministically across:
- mechanism class
- artist
- code hash

No beauty selection enters eligibility.

A genuinely human-curated reference set can be created later after viewing the real corpus.
