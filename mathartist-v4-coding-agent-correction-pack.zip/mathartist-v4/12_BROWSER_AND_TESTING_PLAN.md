# Browser and reproducibility tests

POTENTIAL→BRANCH being untested in browser is a core release blocker.

Add Playwright tests:
1. app loads
2. source switch
3. OPEN batch render
4. POTENTIAL persists
5. POTENTIAL tab shows specimen
6. BRANCH creates children
7. child ancestry is correct
8. source switch does not corrupt selection
9. standalone fixture deterministic
10. injected human events do not alter OPEN_BLIND selection for fixed state/RNG

## Canonical renderer

Reference output must use the exact JS/browser source renderer.
Python must orchestrate, not independently rederive source equations.

## Golden artifacts

For generated scientific artifacts store:
generator + environment lock + expected SHA/reference tolerance.

If regeneration differs, CI fails until explained.
Do not restore old bytes merely to make hashes green.

CI tiers:
- fast
- browser/render
- research smoke
- scheduled/full B25x1000
