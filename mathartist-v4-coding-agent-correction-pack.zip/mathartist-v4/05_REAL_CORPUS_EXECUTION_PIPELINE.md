# Real #つぶやきProcessing execution pipeline

The 994-record registry is useful, but ingestion is not the experiment.

## 1. Eligibility

For every record persist:
- fetch_status
- license_status
- runtime
- parse_status
- run_status
- artist
- original_url
- code_hash
- default_render_hash

Unknown license => metadata/runtime-fetch only, not redistribution.

## 2. Exact default reproduction

Run original code in a pinned browser+p5 environment.

Capture:
- browser version
- p5 version
- canvas
- frame/time
- RNG/noise seed
- screenshot hash
- stdout/errors

No benchmark admission without reproducible default.

## 3. AST literal classification

Classify numeric literals as:
- FIXED_RUNTIME
- CANVAS_GEOMETRY
- SAMPLING_BUDGET
- COLOR_ALPHA
- TIME_STEP
- MATHEMATICAL_COEFFICIENT
- FREQUENCY
- PHASE
- EXPONENT
- INITIAL_CONDITION
- BRANCH_SELECTOR
- UNKNOWN

Do not automatically mutate 200/400/2e4/66/9 just because they are numeric literals.

## 4. Admission

A control enters the genome only if:
- topology remains the same
- role is explicit
- source span recorded
- default reproduces original
- range justified
- constraints recorded

## 5. Two B25 sets

B25_UNBIASED:
deterministic stratified sample across creators/mechanism classes, selected without visual cherry-picking.

B25_REFERENCE:
curated fertile/reference examples such as coupled latent maps, bitwise/predicate geometry, recurrence/orbits, growth/curve, wave/cellular/fluid examples.

## 6. Per seed 1,000 descendants

Recommended:
- 600 Sobol/LHS global
- 300 local perturbations
- 100 boundary/stress
