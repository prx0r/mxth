# MathArtist V4 — coding-agent correction pack

Target repo: `prx0r/mxth`
Reviewed commit: `3d5ac3f4b96ec92a7565bc1134b6a0110a2c5511`

## Mission

Convert V3.3 from a mostly-correct infrastructure/data-ingestion scaffold into the actual emergence experiment.

Do not spend the next cycle adding more sources, more tabs, or more architecture.

The bottleneck is now:

**real executable seeds → defensible control surfaces → large blind search → robust morphology coverage → human stepping-stone selection → reproducible lineages**

## V4 is done only when

1. >=25 real attributed #つぶやきProcessing seeds execute exactly in a pinned p5/browser runtime.
2. Every default program has a reproduction test and code/render hash.
3. Every admitted mutation control has source span, role, evidence, domain and constraints.
4. >=1,000 blind descendants per seed are actually generated: >=25,000 total.
5. OPEN_BLIND consumes zero human preference, attention, rasa or human-branch signals.
6. Morphology coverage is stronger than the current tiny handcrafted descriptor vector.
7. POTENTIAL→BRANCH is browser-tested end to end.
8. Reports show actual discoveries: basins, stepping stones, brittle/fertile regions, parameter transitions and failures.
9. One real frontier-paper executable is integrated and validated before mutation.
10. QRI/rasa/attention remain downstream hypotheses.

Read files in numeric order.
