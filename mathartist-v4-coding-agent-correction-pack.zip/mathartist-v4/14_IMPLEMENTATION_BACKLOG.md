# V4 backlog

## P0
- split OPEN_BLIND from HUMAN_OPEN_ENDED
- remove human-caused branch popularity from OPEN_BLIND
- strict control_surface; quarantine interpretation_genes
- mark VORTEX synthetic fixture
- Playwright POTENTIAL→BRANCH
- canonical renderer
- golden-artifact policy
- seed eligibility pipeline
- exact default reproduction
- AST literal-role classifier
- B25_UNBIASED and B25_REFERENCE

## P1
- stronger morphology ensemble
- non-aesthetic distance calibration
- 25x1000 run
- coverage/basin/sensitivity reports
- first multi-generation human lineage
- blind vs human-open-ended comparison

## P2
- one real Paper2Agent/equivalent integration
- reference validation
- evidence-backed scientific control surface
- small phase-space sweep

## P3
- freeze Rasa/QRI hypotheses
- randomized first-party attention study
- YouTube replication
