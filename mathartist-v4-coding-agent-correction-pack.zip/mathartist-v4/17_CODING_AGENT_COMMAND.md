# Exact coding-agent command

Implement MathArtist V4 from current `prx0r/mxth`.

Do not redesign the system. Do not add speculative source families. Do not optimize beauty.

Order:
1. read V4 pack + current docs
2. resolve P0
3. build exact runnable #つぶやきProcessing harness
4. create B25_UNBIASED and B25_REFERENCE
5. reproduce defaults in pinned runtime
6. AST-based literal role extraction + evidence-backed admission
7. stronger morphology representation + calibration
8. run >=25,000 blind descendants
9. produce per-seed and aggregate evidence reports/contact sheets
10. browser-test POTENTIAL→BRANCH and run a multi-generation human lineage
11. compare BLIND_DIVERSITY vs HUMAN_STEPPING_STONE
12. then run one exact Paper2Agent/equivalent frontier-paper bridge
13. package V4 and a V4_RESULTS.md that separates infrastructure tests, reproducibility tests, measured results and unresolved hypotheses

If a step fails, record the failure instead of substituting a toy mechanism.

Success is not green tests.
Success is a reproducible archive of actual emergence where every specimen's existence is traceable.
