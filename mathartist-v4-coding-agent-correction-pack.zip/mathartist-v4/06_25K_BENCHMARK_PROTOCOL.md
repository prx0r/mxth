# First experiment that matters

Population:
- 25 real benchmark seeds
- 1,000 descendants each
- >=25,000 specimens

Sampling:
- Sobol/LHS for continuous global coverage
- log-space for positive scales
- local Gaussian perturbations
- one-at-a-time sensitivity sweeps
- balanced categorical sampling

Technical failures are logged separately:
- crash
- NaN/Inf
- blank
- irrecoverably clipped
- timeout
- OOM

Ugly output is not a failure.

## Per-seed deliverables

provenance.json
default reference image/runtime
descendants.jsonl/parquet
embeddings
coverage curve
sensitivity table
basin summary
random contact sheet
coverage contact sheet
failure examples

## Fertility is a profile, not one scalar

Report:
- viable_fraction
- coverage_auc
- basin_count
- median_local_sensitivity
- p90_jump_distance
- robustness_radius
- descendant_entropy

Do not rank a winner.
