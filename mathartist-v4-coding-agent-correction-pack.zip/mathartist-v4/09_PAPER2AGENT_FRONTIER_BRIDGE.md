# Paper2Agent / frontier-science bridge

Paper2Agent is valuable because it turns papers + code + data into executable tools and validates outputs against reference artifacts.

MathArtist should consume validated executables, not LLM paraphrases of equations.

Pipeline:

paper + repo + data
→ Paper2Agent/equivalent reproduction
→ validated executable functions
→ MathArtist source adapter
→ evidence-backed control audit
→ exact reference output
→ blind search

Required observable manifest:
- paper identity
- repo commit
- environment lock hash
- executable entrypoints
- reference tests
- immutable mechanism
- admitted controls
- observation controls
- forbidden mutations
- provenance level

Every admitted control needs source location, semantic role, domain, constraints and reference test.

The first frontier-paper integration should be simple and exact rather than glamorous and derived.

Keep current NS26 DERIVED fixture, but do not treat it as proof that paper-to-executable integration works.
