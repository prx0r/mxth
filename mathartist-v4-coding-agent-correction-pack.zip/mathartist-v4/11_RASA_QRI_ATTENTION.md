# Rasa / QRI / attention

Preserve:
attention != liking != valence != arousal != absorption != beauty != rasa

QRI-style structural measures are predictors/hypotheses, not definitions of valence.

Abhinavagupta/rasa belongs downstream as retrospective human response categories, not in generation.

V4 priority is not more QRI/rasa engineering.
First stabilize exact seed execution, blind search, morphology coverage and human branching.

Exploratory human vector may later include:
horizon_5, horizon_10_given_5, horizon_20_given_10, dwell, replay, POTENTIAL, branch, liking, valence, arousal, absorption, retrospective_rasa.

Use a discovery → preregistration → confirmation → replication firewall.
