# Patch blueprints

## Strict surfaces

```python
def surface_for_spec(spec, variant=None, strict=True):
    if "control_surface" in spec:
        return validated_surface(spec["control_surface"], variant)
    if strict:
        raise LegacySourceError(
            f"{spec['id']} has no evidence-backed control_surface"
        )
    return spec.get("interpretation_genes", {})
```

## OPEN blindness

Add a `lineage_channel` to specimens.
Machine fertility in OPEN_BLIND counts only OPEN_BLIND descendants.
Human branches go to HUMAN_OPEN_ENDED.

## Source status

```json
{"status":"EXACT_EXECUTABLE","mutable":true,"strict_surface":true}
```

Hide SYNTHETIC_TEST_FIXTURE from normal source browser.

## Canonical rendering

Reference screenshots use exact JS/browser source module.
Python orchestrates but does not duplicate source equations.

## New tools

tools/seed_eligibility.py
tools/reproduce_seed.cjs
tools/classify_literals.py
tools/admit_controls.py
tools/build_b25.py
tools/run_b25.py
