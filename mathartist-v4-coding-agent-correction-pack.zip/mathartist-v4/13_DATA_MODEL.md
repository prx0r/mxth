# V4 data model

SeedRecord required:
seed_id, artist, original_url, code_hash, license_status, runtime, runtime_lock_hash, default_render_hash, mechanism_class, control_surface_version.

ControlRecord required:
name, type, default, domain, role, source_span, evidence, mutation_transform, constraints, admitted_by, admission_version.

SpecimenRecord required:
specimen_id, seed_id, theta, parent_ids, generation, lineage_channel, rng_seed, runtime_lock_hash, render_hash, technical_status, morphology_embedding_version, morphology_vector.

HumanEvent is separate:
specimen_id, session_id, event_type, timestamp.

Every report gets a derivation ledger:
git commit, config hash, seed-set hash, runtime lock hash, embedding-model hash, generated count, exclusions by reason.
