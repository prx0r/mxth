# What we have vs what we want

| Question | V3.3 | V4 target |
|---|---|---|
| Real creative-math corpus? | 994 metadata records | 25–100 executed exact seeds |
| Exact execution? | not for B25 benchmark | default reproduction per seed |
| Legit controls? | 14,252 literals syntactically extracted | AST/contextual admission with evidence |
| 25k search done? | no | >=25,000 actual descendants |
| Novelty representation robust? | small handcrafted vector | ensemble + frozen learned visual embedding + calibration |
| Source identity diagnostic? | overall 1-NN ~0.549 | report uncertainty; improve representation |
| OPEN fully blind? | mostly, but generic branch counts can leak human branching | strict machine-only OPEN_BLIND |
| Human stepping-stone loop proven? | plumbing exists; browser untested | end-to-end browser tested |
| Sakana lesson implemented cleanly? | partially | separate blind and human-open-ended ecologies |
| Paper2Agent drives frontier math? | adapter scaffold only | one validated end-to-end paper |
| Rasa/QRI ready for claims? | schemas/docs only | wait until generator/search is stable |

The next meaningful output is a dataset and report answering:

1. Which tiny programs have large morphological phase spaces?
2. Which parameters produce smooth variation vs catastrophic collapse?
3. Which unremarkable stepping stones lead to later interesting branches?
4. Does human branching reach regions blind diversity search misses?
5. Which structural motifs recur across independently fertile seeds?
