# V4 architecture delta

Make the architecture stricter, not broader.

## Canonical objects

Seed:
- source identity
- attribution
- exact runnable program
- exact-default reference render/hash
- admitted control surface
- immutable observer/runtime contract

Specimen:
- seed_id
- theta
- RNG seed
- runtime identity
- parent_ids
- render hash
- technical status
- morphology representation
- lineage channel

HumanEvent:
- specimen_id
- session
- event type
- timestamp

## Hard separation

Source space != control space != observation space != human response space.

## Source statuses

Use:
- EXACT_EXECUTABLE
- EXACT_DATA
- DERIVED
- LEGACY_UNVERIFIED
- SYNTHETIC_TEST_FIXTURE

Only mutable production sources with modern evidence-backed control surfaces may enter strict scientific search.

## Kill silent fallback

In strict mode, `surface_for_spec()` must not silently accept `interpretation_genes`.

Missing `control_surface` => read-only / non-mutable until migrated.
