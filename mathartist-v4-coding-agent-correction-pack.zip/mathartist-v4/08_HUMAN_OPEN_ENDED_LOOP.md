# Human stepping-stone loop

1. Show blind batch.
2. Hide QRI/rasa/beauty predictions.
3. Human marks POTENTIAL.
4. Human explicitly presses BRANCH.
5. Create local offspring around exactly those parents.
6. Persist parent IDs and exact deltas.
7. Repeat across generations.
8. Show ancestry on demand.

Do not automatically branch a hidden "top potential" ranking.

Branch scales:
- micro 0.15 sigma
- small 0.35 sigma
- medium 0.7 sigma
- wide 1.25 sigma

Also support:
- one-at-a-time sensitivity branch
- fresh-root injection

Log whether an ancestor itself was liked/beautiful or was merely a useful stepping stone.
