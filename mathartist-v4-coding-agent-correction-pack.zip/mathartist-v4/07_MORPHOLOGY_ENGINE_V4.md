# Morphology engine V4

The current NN distance over a tiny handcrafted vector is a smoke test, not a sufficient morphology representation.

The current source-identity diagnostic already warns about this: several source families overlap heavily.

Do not fix that by tuning thresholds.

## Representation ensemble

A. Handcrafted:
- occupancy
- bbox ratio
- symmetry
- edge density
- spectral entropy
- contrast
- centroid offset
- compressibility
- multiscale component counts
- skeleton length/branch count
- radial profile
- orientation histogram
- fractal/Minkowski proxies
- contour/topology proxies
- temporal recurrence
- optical flow
- spectral anisotropy

B. Frozen general vision embedding:
Use DINOv2, SigLIP or comparable frozen encoder as a morphology proxy.
No prompt.
No aesthetic head.
Fixed model hash/version.

C. Sequence descriptor:
fixed frames, frame embeddings, trajectory length, recurrence, loopiness, change-rate.

## Calibrate distance before coverage

Sample ~300 pairs.
Human labels only:
- nearly same morphology
- related
- clearly different

Use these labels to test monotonic agreement of candidate distances.
This is not beauty labeling.

Use k-center/farthest-point for coverage and clustering only descriptively.
