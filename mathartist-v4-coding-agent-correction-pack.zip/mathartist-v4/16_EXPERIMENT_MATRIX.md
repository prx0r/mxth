# Experiment matrix

Use the same seed set.

A. BLIND_DIVERSITY:
random + recency + phenotype/genotype coverage + machine-only fertility.

B. HUMAN_STEPPING_STONE:
explicit POTENTIAL→BRANCH only.

C. SAKANA_STYLE:
random + recency + branch popularity + optional evaluator ratings.

Compare:
- coverage over evaluations
- lineage depth
- branching entropy
- basin dominance
- jump-distance distribution
- robustness radius
- basin count
- rate of human-selected discoveries
- stepping-stone lag
- fraction of discoveries whose ancestors were not liked/beautiful themselves

Research question:
Which selection ecology best exposes latent morphological structure in fixed mathematical programs?
