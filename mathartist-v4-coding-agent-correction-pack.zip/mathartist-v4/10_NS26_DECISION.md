# NS26 decision

Keep current NS26, but demote its scientific role.

V3.3 correctly labels it DERIVED and restricts the mutable genome to observation/sampling/playback controls.

Therefore it currently tests:
**frozen derived state + variable observation**

It does not yet test:
**scientific parameter emergence in the 2026 Navier–Stokes construction**

Keep as `NS26_DERIVED`.

If a genuine executable family is later reproduced from the paper/repo, create a new source identity such as `NS26_EXECUTABLE` and admit scientific parameters only when the upstream source justifies them.
