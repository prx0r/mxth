# Sakana AI Picbreeder comparison

Sakana's 2026 Picbreeder-VLM experiment is relevant because it studies open-ended archive ecology rather than target optimization.

Useful ingredients:
- shared unbounded archive
- ancestry and branching
- no predefined target
- agents/humans choose stepping stones
- root injection
- archive resampling
- preservation of lucky accidents
- objectives become clear in retrospect

MathArtist should reuse those abstractions, not the CPPN genotype.

## Important V4 correction

Current MathArtist OPEN logic can use branch counts. If human POTENTIAL actions create those branches, branch popularity becomes an indirect human-preference signal.

Split the ecology:

### OPEN_BLIND
Allowed:
- random roots
- recency
- genotype coverage
- phenotype coverage
- technical viability
- machine-only descendant fertility

Forbidden:
- favorite
- dwell
- fullscreen
- replay
- POTENTIAL
- human-caused branch counts
- valence/rasa/attention/YouTube

### HUMAN_OPEN_ENDED
- blind presentation
- explicit human POTENTIAL
- explicit human BRANCH
- full ancestry
- branch popularity may matter here
- do not call it preference-blind

### SAKANA_REPLAY
Optional experimental condition approximating Sakana-style archive resampling with branch popularity/evaluator ratings.

Compare tree depth, branching entropy, archive turnover, basin count, jump sizes, robustness and stepping-stone lag across the three.
