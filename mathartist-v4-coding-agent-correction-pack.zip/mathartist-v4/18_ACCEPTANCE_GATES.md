# Acceptance gates

A Source integrity:
- 25 real seeds
- attribution/hash/license status 100%
- default execute 100%
- default reproduction 100%

B Mutation integrity:
- source evidence for every mutable control
- no runtime/display constants masquerading as math
- default theta reproduces original
- invalid controls fail CI

C Search:
- >=25,000 descendants
- OPEN_BLIND no human-signal dependency
- failures retained
- full lineage/RNG/runtime identity

D Morphology:
- representation versioned
- distance calibrated
- coverage curves
- basin analysis
- random and coverage contact sheets

E Human branching:
- Playwright pass
- explicit branch
- parent/child deltas
- multi-generation lineage

F Claims:
- no beauty optimization in OPEN
- NS26 DERIVED separated
- legacy sources quarantined/migrated
- QRI/rasa excluded from generation
- exploratory vs confirmatory split

G Release:
- clean checkout verification
- dependencies documented
- SHA256 manifest
- no unlicensed code leakage
