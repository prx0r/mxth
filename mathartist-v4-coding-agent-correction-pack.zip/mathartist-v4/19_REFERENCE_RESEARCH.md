# External references used in V4 review

## Sakana AI Picbreeder-VLM
https://sakana.ai/picbreeder-ai/
https://pub.sakana.ai/picbreeder-vlm/

Relevant lesson: open-ended archive branching can discover unplanned stepping stones. Their published experiment also reports limitations of current VLM agents relative to humans in exploiting lucky accidents / making larger conceptual jumps.

## Paper2Agent
https://www.nature.com/articles/s41586-026-11044-y
https://github.com/jmiao24/Paper2Agent

Relevant lesson: paper-to-agent conversion is trustworthy only when executable tools are tested against reference outputs/code and failing tools are excluded.

## #つぶやきProcessing
https://tsubuyaki.art/
https://tsubuyaki.art/about.html
https://tweetprocessing.projectroom.jp/

Relevant lesson: this corpus is useful because the programs are tiny executable phenotype generators. Metadata ingestion alone is not enough; exact execution + controlled parameter search is the real experiment.

## pyribs
https://docs.pyribs.org/en/stable/

Use quality-diversity infrastructure only where it helps coverage. Do not import an aesthetic scalar objective into OPEN_BLIND.
