# Answers to all 30 current CONFUSED.md questions

1. NS26: keep current source frozen/DERIVED. New executable source ID if scientific controls later become legitimate.
2. Nested v3.2 ZIP: remove from canonical releases; keep archives separately.
3. French-flag mismatch: reproducibility failure; fix generator/environment or mark imported/non-regenerable.
4. E0 failure: do not tune threshold; improve representation and calibrate distance.
5. Golden bytes: regenerate+compare in CI; historical canonical bytes require explicit documentation.
6. POTENTIAL→BRANCH: browser test is required.
7. API: strict modern control_surface + source status; legacy read-only.
8. Lenia/Bioelectric/Chladni legacy genes: migrate or mark LEGACY_UNVERIFIED.
9. 25 seeds: deterministic stratified B25_UNBIASED plus curated B25_REFERENCE.
10. 0.6 threshold: remove as acceptance gate; report CV/permutation/bootstrap uncertainty.
11. Python vs JS preview: one canonical renderer; no independent math duplication.
12. novelty: current NN proxy is insufficient; use representation ensemble/calibration.
13. VORTEX: SYNTHETIC_TEST_FIXTURE; hide by default.
14. benchmark naming: separate corpus benchmark from NS26 fixture benchmark.
15. POTENTIAL UX: global human collection with source filters is fine.
16. silent fallback: remove in strict mode.
17. array import: observer controls explicit; no fake scientific controls.
18. standalone mode: deterministic curated local fixture.
19. descriptor drift: one canonical implementation or fixture parity tests.
20. POTENTIAL evolve without selection: keep guard; branching should be explicit.
21. registry paths: strip unavailable local paths or replace with fetch URL+hash+license status.
22. missing 25k: run only after real seeds execute and controls are admitted; 25k NS26 observation sweeps do not count.
23. licenses: audit before redistribution; unknown => metadata/runtime-fetch only.
24. SQLite concurrency: low priority; serialize expansion jobs if needed.
25. RASA_QRI/ATTENTION: read and keep downstream.
26. ARCHITECTURE_V2: move to docs/history.
27. morphology.py: core algorithm must be understood/tested; replace fertility proxy.
28. selfcheck: integrate into CI if useful or delete.
29. video tools: one smoke test after core benchmark.
30. controlsurface examples: schema-test/reference them or delete.
