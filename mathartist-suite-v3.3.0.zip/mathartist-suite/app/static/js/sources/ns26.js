/* NS26 observer — renders the FROZEN similarity scaffold (see ns26_core.js).

   Source state (particle scaffold + tau/rs/zs/vel schedule) is fixed bytes loaded
   once from app/static/data/ns26/. The genome carries OBSERVATION-ONLY controls
   declared in specs/NS26.json: camera (rotation/pitch/zoom), tone mapping of the
   native pulse scalar (threshold/gamma/exposure), sampling (sample/point_size),
   playback (time_rate) and observation phase (swirl). Nothing here may mutate the
   similarity relations; that would change the source-bundle hash. */
import { loadBinary, loadJSON, frameIndex } from '../core/trajectory.js';
import { scaffoldPoint, NS26_FRAMING, NS26_TAU } from './ns26_core.js';

let base = null, sched = null, ready = false;

export async function initNS() {
  if (ready) return;
  [sched, base] = await Promise.all([
    loadJSON('./data/ns26/schedule.json'),
    loadBinary('./data/ns26/base.f32.bin', Float32Array),
  ]);
  ready = true;
}

export function renderNS(canvas, p, t) {
  if (!ready) return;
  const c = canvas.getContext('2d'), W = canvas.width, H = canvas.height, g = p.genome;
  c.fillStyle = `rgba(2,3,3,${Math.max(0.035, 1 - g.trail)})`;
  c.fillRect(0, 0, W, H);
  c.globalCompositeOperation = 'lighter';
  const F = NS26_FRAMING[p.source_variant] || NS26_FRAMING['similarity-core'];
  const frames = sched.frames, fps = sched.fps || 8;
  const fi = frameIndex(t, g.time_rate, frames, fps);
  const tt = t * (g.time_rate || 0.8);
  const S = { tau: sched.tau[fi], rs: sched.rs[fi], zs: sched.zs[fi], vel: sched.vel[fi] };
  const framePhase = (NS26_TAU * fi) / frames;
  const phase = framePhase + tt * S.vel * 0.025;
  const extra = (g.swirl || 0) * S.vel * 0.015 * tt;
  const yaw = (g.rotation || 0) + 0.04 * tt;
  const cy = Math.cos(yaw), sy = Math.sin(yaw);
  const pitch = 0.55 * (g.pitch || 0), cp = Math.cos(pitch), sp = Math.sin(pitch);
  const N = base.length / 3;
  const Ndraw = Math.max(64, Math.min(N, Math.floor(N * (g.sample || 0.85))));
  const zoom = (g.zoom || 1) * F.zoom;
  for (let i = 0; i < Ndraw; i++) {
    const u = base[3 * i], eta = base[3 * i + 1], X = base[3 * i + 2];
    const pt = scaffoldPoint(u, eta, X, S, phase, extra);
    const x = pt[0], y = pt[1] + F.yOff, z = pt[2], q = pt[3];
    if (q < (g.threshold || 0)) continue;
    const x1 = x * cy - z * sy, z1 = x * sy + z * cy;
    const y1 = y * cp - z1 * sp, z2 = y * sp + z1 * cp;
    const per = 1 / (1 + Math.max(-0.7, z2 * 0.13));
    const xx = W / 2 + x1 * W * 0.15 * zoom * per;
    const yy = H / 2 + y1 * H * 0.15 * zoom * per;
    const lum = Math.floor(90 + 165 * Math.pow(q, g.gamma || 0.8));
    c.fillStyle = `rgba(${lum},${lum},${lum},${0.05 + 0.32 * (g.exposure || 1) * q})`;
    const s = g.point_size || 0.8;
    c.fillRect(xx, yy, s, s);
  }
  c.globalCompositeOperation = 'source-over';
}
